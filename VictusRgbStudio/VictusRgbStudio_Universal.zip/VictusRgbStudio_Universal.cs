using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Management;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shell;
using WinForms = System.Windows.Forms;
using MediaColor = System.Windows.Media.Color;
using DrawColor = System.Drawing.Color;

namespace VictusRgbStudio
{
    internal static class NativeMethods
    {
        public const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;
        public const int DWMWA_WINDOW_CORNER_PREFERENCE = 33;
        public const int DWMWCP_ROUND = 2;

        [DllImport("dwmapi.dll")]
        public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

        [StructLayout(LayoutKind.Sequential)]
        public struct MARGINS { public int Left, Right, Top, Bottom; }

        [DllImport("dwmapi.dll")]
        public static extern int DwmExtendFrameIntoClientArea(IntPtr hwnd, ref MARGINS pMarInset);

        [StructLayout(LayoutKind.Sequential)]
        public struct ACCENT_POLICY { public int AccentState, AccentFlags, GradientColor, AnimationId; }

        [StructLayout(LayoutKind.Sequential)]
        public struct WINDOWCOMPOSITIONATTRIBDATA { public int Attribute; public IntPtr Data; public int SizeOfData; }

        [DllImport("user32.dll")]
        public static extern int SetWindowCompositionAttribute(IntPtr hwnd, ref WINDOWCOMPOSITIONATTRIBDATA data);

        public const int WH_KEYBOARD_LL = 13;
        public const int WM_KEYDOWN = 0x0100;
        public const int WM_SYSKEYDOWN = 0x0104;
        public delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        [StructLayout(LayoutKind.Sequential)]
        public struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }

        [DllImport("user32.dll")]
        public static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        [DllImport("user32.dll")]
        public static extern IntPtr GetDC(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);

        [DllImport("gdi32.dll")]
        public static extern int SetStretchBltMode(IntPtr hdc, int mode);

        [DllImport("gdi32.dll")]
        public static extern bool StretchBlt(IntPtr hdcDest, int xDest, int yDest, int wDest, int hDest,
            IntPtr hdcSrc, int xSrc, int ySrc, int wSrc, int hSrc, int rop);

        [DllImport("kernel32.dll")]
        public static extern bool SetProcessWorkingSetSize(IntPtr proc, IntPtr min, IntPtr max);

        [DllImport("psapi.dll")]
        public static extern bool EmptyWorkingSet(IntPtr hProcess);
    }

    internal static class AudioMeter
    {
        [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
        private class MMDeviceEnumerator { }

        [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IMMDeviceEnumerator
        {
            int NotImpl1();
            int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice ppDevice);
        }

        [Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IMMDevice
        {
            int Activate(ref Guid iid, int dwClsCtx, IntPtr pActivationParams, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
        }

        [Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IAudioMeterInformation
        {
            int GetPeakValue(out float pfPeak);
        }

        private static IAudioMeterInformation _meter;

        public static float GetPeak()
        {
            try
            {
                if (_meter == null)
                {
                    var enumerator = (IMMDeviceEnumerator)(new MMDeviceEnumerator());
                    IMMDevice device;
                    if ((enumerator.GetDefaultAudioEndpoint(0, 0, out device) == 0 ||
                         enumerator.GetDefaultAudioEndpoint(0, 1, out device) == 0) && device != null)
                    {
                        Guid iid = typeof(IAudioMeterInformation).GUID;
                        object obj;
                        if (device.Activate(ref iid, 23, IntPtr.Zero, out obj) == 0)
                            _meter = obj as IAudioMeterInformation;
                    }
                }
                if (_meter != null)
                {
                    float peak;
                    if (_meter.GetPeakValue(out peak) == 0) return peak;
                    _meter = null;
                }
            }
            catch { _meter = null; }
            return 0f;
        }
    }

    public class HpWmiController : IDisposable
    {
        private static readonly byte[] SignSecu = new byte[] { 0x53, 0x45, 0x43, 0x55 };
        private const uint CmdSystem = 0x20008;
        private const uint CmdLighting = 0x20009;

        private ManagementObject _wmiInstance;
        private ManagementClass _dataInClass;
        private ManagementBaseObject _cachedInData;
        private ManagementBaseObject _cachedInParams4;
        private readonly byte[] _writeTableBuf = new byte[128];

        public bool IsConnected { get; private set; }
        public string LastError { get; private set; }

        public bool Connect()
        {
            try
            {
                var scope = new ManagementScope(@"\\.\root\wmi");
                scope.Connect();
                var wmiClass = new ManagementClass(scope, new ManagementPath("hpqBIntM"), null);
                foreach (ManagementObject obj in wmiClass.GetInstances()) { _wmiInstance = obj; break; }
                if (_wmiInstance == null) { LastError = "hpqBIntM WMI instance not found."; IsConnected = false; return false; }
                _dataInClass = new ManagementClass(scope, new ManagementPath("hpqBDataIn"), null);
                IsConnected = true;
                LastError = "";
                return true;
            }
            catch (Exception ex) { LastError = ex.Message; IsConnected = false; return false; }
        }

        private byte[] InvokeBios(uint command, uint commandType, byte[] payload, int outputSize, out uint returnCode)
        {
            returnCode = 0xFFFFFFFF;
            if (!IsConnected && !Connect()) return null;
            string methodName = "hpqBIOSInt" + outputSize;
            try
            {
                if (_cachedInData == null) _cachedInData = _dataInClass.CreateInstance();
                _cachedInData["Sign"] = SignSecu;
                _cachedInData["Command"] = command;
                _cachedInData["CommandType"] = commandType;
                _cachedInData["Size"] = (uint)(payload != null ? payload.Length : 0);
                _cachedInData["hpqBData"] = payload ?? new byte[0];

                ManagementBaseObject inParams = (outputSize == 4 && _cachedInParams4 != null)
                    ? _cachedInParams4
                    : _wmiInstance.GetMethodParameters(methodName);
                if (outputSize == 4 && _cachedInParams4 == null) _cachedInParams4 = inParams;
                inParams["InData"] = _cachedInData;

                using (ManagementBaseObject outParams = _wmiInstance.InvokeMethod(methodName, inParams, null))
                {
                    if (outputSize != 4) inParams.Dispose();
                    if (outParams == null) return null;
                    using (var outData = outParams["OutData"] as ManagementBaseObject)
                    {
                        if (outData == null) return null;
                        returnCode = Convert.ToUInt32(outData["rwReturnCode"]);
                        return outData["Data"] as byte[];
                    }
                }
            }
            catch (Exception ex) { LastError = ex.Message; return null; }
        }

        public int GetKeyboardType(out uint returnCode)
        {
            byte[] data = InvokeBios(CmdSystem, 0x2B, new byte[] { 0, 0, 0, 0 }, 4, out returnCode);
            return (data != null && data.Length > 0 && returnCode == 0) ? data[0] : -1;
        }

        public double GetChassisTempCelsius()
        {
            uint rc;
            byte[] data = InvokeBios(CmdSystem, 0x23, new byte[] { 1, 0, 0, 0 }, 4, out rc);
            return (data != null && data.Length > 0 && rc == 0) ? data[0] : -1;
        }

        public byte[] ReadColorTable(out uint returnCode) { return InvokeBios(CmdLighting, 0x02, new byte[] { 0, 0, 0, 0 }, 128, out returnCode); }

        public bool WriteColorTable(byte[] table, out uint returnCode)
        {
            if (table == null || table.Length < 128) { returnCode = 5; return false; }
            Array.Copy(table, _writeTableBuf, 128);
            InvokeBios(CmdLighting, 0x03, _writeTableBuf, 4, out returnCode);
            return returnCode == 0;
        }

        public bool SetBacklightOn(bool on, out uint returnCode)
        {
            InvokeBios(CmdLighting, 0x05, new byte[] { (byte)(on ? 0xE4 : 0x64), 0, 0, 0 }, 4, out returnCode);
            return returnCode == 0;
        }

        public bool SetAllZonesColor(byte[] baseTable, byte r, byte g, byte b, out uint returnCode)
        {
            if (baseTable != null && baseTable.Length >= 128) Array.Copy(baseTable, _writeTableBuf, 128);
            for (int z = 0; z < 4; z++)
            {
                int off = 25 + (z * 3);
                _writeTableBuf[off] = r; _writeTableBuf[off + 1] = g; _writeTableBuf[off + 2] = b;
            }
            InvokeBios(CmdLighting, 0x03, _writeTableBuf, 4, out returnCode);
            return returnCode == 0;
        }

        public void Dispose()
        {
            if (_cachedInParams4 != null) _cachedInParams4.Dispose();
            if (_cachedInData != null) _cachedInData.Dispose();
            if (_dataInClass != null) _dataInClass.Dispose();
            if (_wmiInstance != null) _wmiInstance.Dispose();
        }
    }

    // =========================================================
    // Headless Background Engine + Tray Host (~12-18 MB RAM)
    // =========================================================
    public class RgbEngine : IDisposable
    {
        public const string TaskName = "VictusRgbStudio";
        public static readonly string[] ModeNames = new[]
        {
            "Random Color Pulse", "Smooth Random Morph", "Heartbeat Pulse",
            "Rainbow Spectrum", "Custom Palette Cycle", "Music Visualizer",
            "Screen Ambilight", "Keypress Flash", "Thermal Gauge",
            "Music Video Ambience", "Aurora Drift", "Cyberpunk Strobe",
            "Emerald Aurora", "Solar Flare", "Bioluminescent Tide",
            "Ember Drift", "Twilight Prism", "Plasma Arc"
        };
        public static readonly string[] ModeSubtitles = new[]
        {
            "Breathe & switch vibrant colors", "Continuous crossfade wave", "Double-beat random glow",
            "Full spectrum breathing", "Cycle your 2–3 chosen colors", "Live Windows audio reactive",
            "Mirrors display dominant hue", "Flares on every keystroke", "Live CPU / chassis temperature",
            "Screen ambilight + audio beat", "Northern lights emerald-violet", "Neon magenta & cyan pulse",
            "Lush northern lights green curtain", "Warm amber & gold flare spikes", "Oceanic teal & indigo swells",
            "Smoldering charcoal-orange glow", "Rose, lavender & midnight dusk", "Electric violet & ice-blue surge"
        };

        public readonly string ExePath;
        public readonly string ModelName;
        public readonly string ConfigPath;
        public readonly HpWmiController Wmi = new HpWmiController();

        private readonly Random _rng = new Random();
        private readonly WinForms.Timer _timer = new WinForms.Timer();
        private readonly WinForms.NotifyIcon _trayIcon;
        private readonly System.Drawing.Icon _trayIconOff;
        private readonly System.Drawing.Icon _trayIconOn;
        private readonly WinForms.ToolStripMenuItem _trayToggleItem;

        private IntPtr _hookId = IntPtr.Zero;
        private NativeMethods.LowLevelKeyboardProc _hookProc;
        private long _lastKeyTick = 0;

        public byte[] OriginalTable = null;
        public bool IsRunning = false;
        public bool IsSleeping = false;
        public bool IsDimmed = false;
        public string HardwareWarning = "";

        // Settings
        public int ModeIndex = 0;
        public int[] ModeOrder = new[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17 };
        public int LockedModeIndex = -1;
        public int Speed = 8;
        public int MaxBright = 100;
        public int MinBright = 5;
        public DrawColor CycColor1 = DrawColor.FromArgb(255, 55, 95);
        public DrawColor CycColor2 = DrawColor.FromArgb(55, 235, 145);
        public DrawColor CycColor3 = DrawColor.FromArgb(165, 85, 255);
        public bool CycUseThree = true;
        public DrawColor KeyColor = DrawColor.FromArgb(110, 185, 255);
        public bool KeyRandom = false;
        public DrawColor TempCoolColor = DrawColor.FromArgb(75, 195, 255);
        public DrawColor TempMidColor = DrawColor.FromArgb(255, 185, 45);
        public DrawColor TempHotColor = DrawColor.FromArgb(255, 55, 75);
        public int TempCoolVal = 45;
        public int TempHotVal = 80;
        public bool BatterySaver = true;
        public bool IdleSleep = false;
        public bool PatternColorLock = false;
        public DrawColor PatternLockColor = DrawColor.FromArgb(255, 55, 95);
        public bool AutoHideUi = false;
        public int AutoHideMins = 2;
        public int IdleMins = 5;
        public bool IdleDim = false;
        public int IdleDimMins = 1;

        // Live Frame State
        private double _phase = 0.0, _hue = 0.0, _audioSmooth = 0.0, _audioPeakEnv = 0.15;
        private DrawColor _currentColor = DrawColor.FromArgb(110, 145, 255);
        private DrawColor _nextColor = DrawColor.FromArgb(175, 95, 255);
        private int _customIdx = 0;
        private DateTime _lastTempRead = DateTime.MinValue;
        public double CachedTemp = 45.0;
        public byte TargetR = 38, TargetG = 40, TargetB = 46;
        private int _lastSentR = -1, _lastSentG = -1, _lastSentB = -1;

        private Bitmap _screenBmp;
        private Graphics _screenG;
        private readonly byte[] _screenBuf = new byte[32 * 18 * 4];
        private int _tickCount = 0;

        private readonly SynchronizationContext _mainSync;
        private Thread _wpfThread;
        private System.Windows.Threading.Dispatcher _wpfDispatcher;
        private readonly ManualResetEventSlim _wpfReady = new ManualResetEventSlim(false);
        private MainWindow _activeWindow;
        public event Action FrameUpdated;

        public RgbEngine(bool autoStart, bool startMinimized)
        {
            _mainSync = SynchronizationContext.Current ?? new WinForms.WindowsFormsSynchronizationContext();
            ExePath = Assembly.GetExecutingAssembly().Location;
            ModelName = DetectModelName();
            ConfigPath = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(ExePath), "victus_rgb.cfg");
            LoadConfig();

            var menu = new WinForms.ContextMenuStrip();
            menu.Items.Add("Open Studio", null, delegate { OpenStudio(); });
            _trayToggleItem = new WinForms.ToolStripMenuItem("Start RGB", null, delegate { Toggle(); });
            menu.Items.Add(_trayToggleItem);
            menu.Items.Add(new WinForms.ToolStripSeparator());
            menu.Items.Add("Exit", null, delegate { WinForms.Application.Exit(); });

            _trayIconOff = GetAppIcon(ExePath);
            _trayIconOn = CreateVectorAppIcon(true);
            _trayIcon = new WinForms.NotifyIcon
            {
                Icon = _trayIconOff,
                Text = "Victus RGB Studio",
                ContextMenuStrip = menu,
                Visible = true
            };
            _trayIcon.DoubleClick += delegate { OpenStudio(); };

            _timer.Interval = 90;
            _timer.Tick += OnTick;

            _hookProc = HookCallback;
            _hookId = NativeMethods.SetWindowsHookEx(NativeMethods.WH_KEYBOARD_LL, _hookProc, NativeMethods.GetModuleHandle(null), 0);

            if (autoStart) Start();
            if (!startMinimized) OpenStudio();
            else TrimMemory();
        }

        private static string DetectModelName()
        {
            try
            {
                using (var s = new ManagementObjectSearcher("SELECT Model FROM Win32_ComputerSystem"))
                {
                    foreach (ManagementObject o in s.Get())
                    {
                        string m = (o["Model"] != null) ? o["Model"].ToString().Trim() : "";
                        if (!string.IsNullOrEmpty(m)) return m;
                    }
                }
            }
            catch { }
            return "HP Victus RGB";
        }

        public static System.Drawing.Icon GetAppIcon(string exePath)
        {
            try
            {
                if (!string.IsNullOrEmpty(exePath) && File.Exists(exePath))
                {
                    var assoc = System.Drawing.Icon.ExtractAssociatedIcon(exePath);
                    if (assoc != null) return assoc;
                }
            }
            catch { }
            return CreateVectorAppIcon(false);
        }

        public static System.Drawing.Icon CreateVectorAppIcon(bool isOn = false)
        {
            using (var bmp = new Bitmap(64, 64))
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(DrawColor.Transparent);

                // Vector rendition of the Currents optical orb icon (pop-out orb)
                using (var path = new System.Drawing.Drawing2D.GraphicsPath())
                {
                    int r = 15;
                    path.AddArc(2, 2, r * 2, r * 2, 180, 90);
                    path.AddArc(60 - r * 2, 2, r * 2, r * 2, 270, 90);
                    path.AddArc(60 - r * 2, 60 - r * 2, r * 2, r * 2, 0, 90);
                    path.AddArc(2, 60 - r * 2, r * 2, r * 2, 90, 90);
                    path.CloseFigure();

                    using (var bg = new System.Drawing.Drawing2D.LinearGradientBrush(
                        new System.Drawing.Rectangle(2, 2, 60, 60),
                        DrawColor.FromArgb(255, 26, 28, 34),
                        DrawColor.FromArgb(255, 14, 15, 20), 45f))
                        g.FillPath(bg, path);

                    g.SetClip(path);
                    using (var linePen = new System.Drawing.Pen(DrawColor.FromArgb(65, 205, 212, 225), 1.0f))
                    {
                        for (int k = -3; k <= 3; k++)
                        {
                            if (k == 0) continue;
                            int off = k * 8;
                            g.DrawBezier(linePen, 2 + off, 2, 24 + off, 22, 40 + off, 42, 62 + off, 62);
                        }
                    }
                    using (var crimPen = new System.Drawing.Pen(DrawColor.FromArgb(215, 210, 55, 85), 2.6f))
                        g.DrawLine(crimPen, 4, 4, 60, 60);
                    g.ResetClip();

                    // Deep drop-shadow or green outer glow halo behind orb
                    using (var haloBrush = new SolidBrush(isOn ? DrawColor.FromArgb(135, 34, 240, 100) : DrawColor.FromArgb(150, 0, 0, 0)))
                        g.FillEllipse(haloBrush, 10, 10, 44, 44);

                    // Pop-out optical glass orb (40x40)
                    using (var orbPath = new System.Drawing.Drawing2D.GraphicsPath())
                    {
                        orbPath.AddEllipse(12, 12, 40, 40);
                        g.SetClip(orbPath);
                        using (var pgb = new System.Drawing.Drawing2D.PathGradientBrush(orbPath))
                        {
                            pgb.CenterPoint = new System.Drawing.PointF(24, 22);
                            pgb.CenterColor = isOn ? DrawColor.FromArgb(255, 130, 255, 165) : DrawColor.FromArgb(245, 155, 160, 175);
                            pgb.SurroundColors = new[] { isOn ? DrawColor.FromArgb(255, 18, 145, 55) : DrawColor.FromArgb(250, 24, 26, 34) };
                            g.FillEllipse(pgb, 12, 12, 40, 40);
                        }
                        using (var refrPen = new System.Drawing.Pen(isOn ? DrawColor.FromArgb(110, 220, 255, 230) : DrawColor.FromArgb(220, 220, 72, 92), 2.6f))
                            g.DrawBezier(refrPen, 20, 12, 29, 28, 36, 39, 45, 50);
                        using (var hi = new SolidBrush(DrawColor.FromArgb(isOn ? 165 : 115, 255, 255, 255)))
                            g.FillEllipse(hi, 18, 16, 14, 10);
                        g.ResetClip();
                        using (var orbRim = new System.Drawing.Pen(isOn ? DrawColor.FromArgb(240, 165, 255, 195) : DrawColor.FromArgb(220, 240, 244, 252), 1.6f))
                            g.DrawEllipse(orbRim, 12, 12, 40, 40);
                    }
                    using (var rim = new System.Drawing.Pen(DrawColor.FromArgb(115, 255, 255, 255), 1.2f))
                        g.DrawPath(rim, path);
                }

                return (System.Drawing.Icon)System.Drawing.Icon.FromHandle(bmp.GetHicon()).Clone();
            }
        }

        public void OpenStudio()
        {
            if (_wpfThread == null)
            {
                _wpfThread = new Thread(delegate()
                {
                    var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
                    app.DispatcherUnhandledException += delegate(object s, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs exArgs)
                    {
                        Program.LogCrash("WPF.DispatcherUnhandledException", exArgs.Exception);
                    };
                    _wpfDispatcher = System.Windows.Threading.Dispatcher.CurrentDispatcher;
                    _wpfReady.Set();
                    app.Run();
                });
                _wpfThread.SetApartmentState(ApartmentState.STA);
                _wpfThread.IsBackground = true;
                _wpfThread.Start();
                _wpfReady.Wait();
            }

            _wpfDispatcher.BeginInvoke(new Action(delegate
            {
                if (_activeWindow != null)
                {
                    if (_activeWindow.WindowState == WindowState.Minimized) _activeWindow.WindowState = WindowState.Normal;
                    _activeWindow.Activate();
                    return;
                }
                _activeWindow = new MainWindow(this);
                _activeWindow.Closed += delegate { _activeWindow = null; TrimMemory(); };
                _activeWindow.Show();
                _activeWindow.Activate();
            }));
        }

        public void Toggle()
        {
            _mainSync.Post(delegate { if (IsRunning) Stop(); else Start(); }, null);
        }

        public bool Start()
        {
            if (!Wmi.IsConnected && !Wmi.Connect()) return false;
            uint rc;
            if (OriginalTable == null) { OriginalTable = Wmi.ReadColorTable(out rc); if (OriginalTable == null || OriginalTable.Length < 128) OriginalTable = new byte[128]; }
            uint rcKt;
            int kt = Wmi.GetKeyboardType(out rcKt);
            if (kt == 3) HardwareWarning = "Per-key USB RGB (not WMI)";
            else if (OriginalTable == null || OriginalTable.Length < 28) HardwareWarning = "No WMI RGB table detected";
            else HardwareWarning = "";
            Wmi.SetBacklightOn(true, out rc);
            _phase = 0.0;
            _lastSentR = -1;
            IsRunning = true;
            IsSleeping = false;
            IsDimmed = false;
            _trayToggleItem.Text = "Stop RGB";
            if (_trayIcon != null && _trayIconOn != null) _trayIcon.Icon = _trayIconOn;
            _timer.Start();
            return true;
        }

        public void Stop()
        {
            _timer.Stop();
            IsRunning = false;
            _trayToggleItem.Text = "Start RGB";
            if (_trayIcon != null && _trayIconOff != null) _trayIcon.Icon = _trayIconOff;
            if (OriginalTable != null && Wmi.IsConnected)
            {
                uint rc;
                Wmi.SetBacklightOn(true, out rc);
                Wmi.WriteColorTable(OriginalTable, out rc);
            }
        }

        private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && (wParam == (IntPtr)NativeMethods.WM_KEYDOWN || wParam == (IntPtr)NativeMethods.WM_SYSKEYDOWN))
                _lastKeyTick = Environment.TickCount;
            return NativeMethods.CallNextHookEx(_hookId, nCode, wParam, lParam);
        }

        private void OnTick(object sender, EventArgs e)
        {
            if (IdleSleep || IdleDim)
            {
                var lii = new NativeMethods.LASTINPUTINFO { cbSize = (uint)Marshal.SizeOf(typeof(NativeMethods.LASTINPUTINFO)) };
                if (NativeMethods.GetLastInputInfo(ref lii))
                {
                    uint idleMs = (uint)Environment.TickCount - lii.dwTime;
                    if (IdleSleep && idleMs > (uint)(IdleMins * 60000))
                    {
                        if (!IsSleeping) { uint rc; Wmi.SetBacklightOn(false, out rc); IsSleeping = true; IsDimmed = false; _timer.Interval = 500; if (_trayIcon != null && _trayIconOff != null) _trayIcon.Icon = _trayIconOff; }
                        return;
                    }
                    else if (IsSleeping)
                    {
                        uint rc; Wmi.SetBacklightOn(true, out rc); IsSleeping = false; _timer.Interval = 90; if (_trayIcon != null && _trayIconOn != null) _trayIcon.Icon = _trayIconOn;
                    }

                    if (IdleDim && idleMs > (uint)(IdleDimMins * 60000))
                    {
                        if (!IsDimmed) { IsDimmed = true; _timer.Interval = 180; }
                    }
                    else if (IsDimmed)
                    {
                        IsDimmed = false; _timer.Interval = 90;
                    }
                }
            }
            else if (IsDimmed)
            {
                IsDimmed = false; _timer.Interval = 90;
            }

            double speed = Speed * 0.015;
            double minF = MinBright / 100.0;
            double maxF = Math.Max(minF + 0.05, MaxBright / 100.0);
            var pwr = WinForms.SystemInformation.PowerStatus;
            if (BatterySaver && pwr.PowerLineStatus == WinForms.PowerLineStatus.Offline && pwr.BatteryLifePercent <= 0.40f)
                maxF = Math.Min(maxF, 0.40);
            if (IsDimmed)
            {
                minF = Math.Min(minF, 0.05);
                maxF = Math.Min(maxF, 0.20);
            }

            DrawColor baseCol = _currentColor;
            double bright = 1.0;

            if (ModeIndex == 0)
            {
                _phase += speed;
                if (_phase >= Math.PI * 2.0) { _phase -= Math.PI * 2.0; _currentColor = PatternColorLock ? PatternLockColor : PickRandomVibrantColor(_currentColor); }
                bright = minF + (maxF - minF) * (0.5 - 0.5 * Math.Cos(_phase));
                baseCol = PatternColorLock ? PatternLockColor : _currentColor;
            }
            else if (ModeIndex == 1)
            {
                _phase += speed * 0.65;
                if (_phase >= 1.0) { _phase -= 1.0; _currentColor = _nextColor; _nextColor = PickRandomVibrantColor(_currentColor); }
                baseCol = LerpColor(_currentColor, _nextColor, _phase);
                bright = minF + (maxF - minF) * (0.5 + 0.5 * Math.Sin(_phase * Math.PI * 2.0));
            }
            else if (ModeIndex == 2)
            {
                _phase += speed * 0.85;
                if (_phase >= 1.0) { _phase -= 1.0; _currentColor = PatternColorLock ? PatternLockColor : PickRandomVibrantColor(_currentColor); }
                double p = 0.0;
                if (_phase < 0.22) p = Math.Sin((_phase / 0.22) * Math.PI);
                else if (_phase >= 0.28 && _phase < 0.52) p = 0.8 * Math.Sin(((_phase - 0.28) / 0.24) * Math.PI);
                bright = minF + (maxF - minF) * p;
                baseCol = PatternColorLock ? PatternLockColor : _currentColor;
            }
            else if (ModeIndex == 3)
            {
                _hue = (_hue + speed * 42.0) % 360.0;
                _phase = (_phase + speed) % (Math.PI * 2.0);
                bright = minF + (maxF - minF) * (0.5 + 0.5 * Math.Sin(_phase));
                baseCol = HsvToColor(_hue, 1.0, 1.0);
            }
            else if (ModeIndex == 4)
            {
                int count = CycUseThree ? 3 : 2;
                _phase += speed * 0.65;
                if (_phase >= 1.0) { _phase -= 1.0; _customIdx = (_customIdx + 1) % count; }
                int idxA = _customIdx % count, idxB = (_customIdx + 1) % count;
                DrawColor cA = (idxA == 0) ? CycColor1 : ((idxA == 1) ? CycColor2 : CycColor3);
                DrawColor cB = (idxB == 0) ? CycColor1 : ((idxB == 1) ? CycColor2 : CycColor3);
                baseCol = LerpColor(cA, cB, _phase);
                bright = minF + (maxF - minF) * (0.5 + 0.5 * Math.Sin(_phase * Math.PI * 2.0));
            }
            else if (ModeIndex == 5)
            {
                float peak = AudioMeter.GetPeak();
                _audioPeakEnv = Math.Max(0.05, Math.Max(peak, _audioPeakEnv * 0.985));
                double norm = Math.Min(1.0, peak / _audioPeakEnv);
                double prevSmooth = _audioSmooth;
                _audioSmooth = _audioSmooth * 0.35 + norm * 0.65;
                if (!PatternColorLock && norm - prevSmooth > 0.22 && _phase > 0.20) { _currentColor = PickRandomVibrantColor(_currentColor); _phase = 0; }
                _phase += 0.09;
                bright = minF + (maxF - minF) * _audioSmooth;
                baseCol = PatternColorLock ? PatternLockColor : _currentColor;
            }
            else if (ModeIndex == 6)
            {
                _currentColor = LerpColor(_currentColor, SampleScreenColor(), 0.35);
                baseCol = _currentColor;
                bright = maxF;
            }
            else if (ModeIndex == 7)
            {
                long sinceKey = Environment.TickCount - _lastKeyTick;
                if (sinceKey < 100 && KeyRandom) KeyColor = PickRandomVibrantColor(KeyColor);
                double decay = Math.Max(0.0, 1.0 - (sinceKey / 700.0));
                bright = minF + (maxF - minF) * decay;
                baseCol = KeyColor;
            }
            else if (ModeIndex == 8)
            {
                if ((DateTime.Now - _lastTempRead).TotalSeconds >= 2.0) { CachedTemp = ReadCpuOrChassisTemp(); _lastTempRead = DateTime.Now; }
                double cool = TempCoolVal;
                double hot = Math.Max(cool + 5, TempHotVal);
                double mid = (cool + hot) / 2.0;
                if (CachedTemp <= cool) baseCol = TempCoolColor;
                else if (CachedTemp >= hot) baseCol = TempHotColor;
                else if (CachedTemp < mid) baseCol = LerpColor(TempCoolColor, TempMidColor, (CachedTemp - cool) / (mid - cool));
                else baseCol = LerpColor(TempMidColor, TempHotColor, (CachedTemp - mid) / (hot - mid));

                if (CachedTemp >= hot) { _phase = (_phase + speed * 1.4) % (Math.PI * 2.0); bright = minF + (maxF - minF) * (0.5 + 0.5 * Math.Sin(_phase)); }
                else bright = maxF;
            }
            else if (ModeIndex == 9)
            {
                // Music Video Ambience: Screen Ambilight hue + live audio reactive pulse
                _currentColor = LerpColor(_currentColor, SampleScreenColor(), 0.35);
                float peak = AudioMeter.GetPeak();
                _audioPeakEnv = Math.Max(0.05, Math.Max(peak, _audioPeakEnv * 0.985));
                double norm = Math.Min(1.0, peak / _audioPeakEnv);
                _audioSmooth = _audioSmooth * 0.35 + norm * 0.65;
                baseCol = _currentColor;
                bright = minF + (maxF - minF) * Math.Min(1.0, 0.25 + _audioSmooth * 0.85);
            }
            else if (ModeIndex == 10)
            {
                // Aurora Drift: emerald-cyan-violet wave
                _phase = (_phase + speed * 0.7) % (Math.PI * 2.0);
                double auroraHue = 215.0 + 65.0 * Math.Sin(_phase * 0.5);
                baseCol = HsvToColor(auroraHue, 0.92, 1.0);
                bright = minF + (maxF - minF) * (0.55 + 0.45 * Math.Sin(_phase * 1.3));
            }
            else if (ModeIndex == 11)
            {
                // Cyberpunk Strobe: rhythmic magenta / cyan / ultraviolet
                _phase += speed * 1.1;
                if (_phase >= 1.0) { _phase -= 1.0; _customIdx = (_customIdx + 1) % 3; }
                baseCol = (_customIdx == 0) ? DrawColor.FromArgb(255, 42, 133) : ((_customIdx == 1) ? DrawColor.FromArgb(0, 229, 255) : DrawColor.FromArgb(138, 43, 255));
                double decay = Math.Max(0.0, 1.0 - _phase * 0.85);
                bright = minF + (maxF - minF) * (decay * decay);
            }
            else if (ModeIndex == 12)
            {
                // Emerald Aurora: lush northern-lights green curtain
                _phase = (_phase + speed * 0.65) % (Math.PI * 2.0);
                double gHue = 142.0 + 26.0 * Math.Sin(_phase * 0.7) + 10.0 * Math.Cos(_phase * 1.5);
                baseCol = HsvToColor(gHue, 0.90, 1.0);
                bright = minF + (maxF - minF) * (0.50 + 0.35 * Math.Sin(_phase) + 0.15 * Math.Sin(_phase * 2.3));
            }
            else if (ModeIndex == 13)
            {
                // Solar Flare: warm amber-crimson with bright gold flare spikes
                _phase = (_phase + speed * 0.9) % (Math.PI * 2.0);
                double flare = Math.Pow(Math.Max(0.0, Math.Sin(_phase * 1.5)), 6.0);
                baseCol = LerpColor(DrawColor.FromArgb(255, 75, 25), DrawColor.FromArgb(255, 225, 130), flare);
                bright = minF + (maxF - minF) * Math.Min(1.0, 0.45 + 0.25 * Math.Sin(_phase) + 0.45 * flare);
            }
            else if (ModeIndex == 14)
            {
                // Bioluminescent Tide: oceanic teal & deep-indigo swells
                _phase = (_phase + speed * 0.55) % (Math.PI * 2.0);
                double swell = Math.Pow(0.5 + 0.5 * Math.Sin(_phase), 1.6);
                baseCol = LerpColor(DrawColor.FromArgb(30, 55, 165), DrawColor.FromArgb(20, 240, 200), swell);
                bright = minF + (maxF - minF) * (0.20 + 0.80 * swell);
            }
            else if (ModeIndex == 15)
            {
                // Ember Drift: smoldering charcoal-orange with organic crackle
                _phase = (_phase + speed * 0.8) % (Math.PI * 2.0);
                double crackle = 0.5 + 0.3 * Math.Sin(_phase * 3.1) + 0.2 * Math.Cos(_phase * 5.7);
                baseCol = LerpColor(DrawColor.FromArgb(145, 32, 8), DrawColor.FromArgb(255, 120, 20), crackle);
                bright = minF + (maxF - minF) * (0.25 + 0.55 * crackle);
            }
            else if (ModeIndex == 16)
            {
                // Twilight Prism: rose, lavender & midnight-blue dusk
                _phase = (_phase + speed * 0.5) % (Math.PI * 2.0);
                double tHue = 285.0 + 50.0 * Math.Sin(_phase * 0.6);
                baseCol = HsvToColor(tHue, 0.82, 1.0);
                bright = minF + (maxF - minF) * (0.48 + 0.40 * Math.Sin(_phase));
            }
            else
            {
                // Plasma Arc: electric violet & ice-blue surges
                _phase = (_phase + speed * 1.25) % (Math.PI * 2.0);
                double arc = 0.5 + 0.5 * Math.Sin(_phase * 2.0);
                baseCol = LerpColor(DrawColor.FromArgb(130, 45, 255), DrawColor.FromArgb(115, 225, 255), arc);
                bright = minF + (maxF - minF) * (0.35 + 0.65 * Math.Pow(arc, 1.4));
            }

            TargetR = (byte)Math.Max(0, Math.Min(255, Math.Round(baseCol.R * bright)));
            TargetG = (byte)Math.Max(0, Math.Min(255, Math.Round(baseCol.G * bright)));
            TargetB = (byte)Math.Max(0, Math.Min(255, Math.Round(baseCol.B * bright)));

            if (TargetR != _lastSentR || TargetG != _lastSentG || TargetB != _lastSentB)
            {
                _lastSentR = TargetR; _lastSentG = TargetG; _lastSentB = TargetB;
                uint rcW;
                Wmi.SetAllZonesColor(OriginalTable, TargetR, TargetG, TargetB, out rcW);
            }

            var handler = FrameUpdated;
            if (handler != null) handler();

            if (ModeIndex != 6 && ModeIndex != 9 && _screenBmp != null)
            {
                _screenG.Dispose(); _screenG = null;
                _screenBmp.Dispose(); _screenBmp = null;
            }

            if (++_tickCount >= 500)
            {
                _tickCount = 0;
                if (_activeWindow == null)
                {
                    GC.Collect(2, GCCollectionMode.Optimized, false);
                    IntPtr hProc = Process.GetCurrentProcess().Handle;
                    NativeMethods.SetProcessWorkingSetSize(hProc, (IntPtr)(-1), (IntPtr)(-1));
                    NativeMethods.EmptyWorkingSet(hProc);
                }
            }
        }

        private DrawColor SampleScreenColor()
        {
            IntPtr hdcSrc = IntPtr.Zero;
            try
            {
                var bounds = WinForms.Screen.PrimaryScreen.Bounds;
                hdcSrc = NativeMethods.GetDC(IntPtr.Zero);
                if (_screenBmp == null) { _screenBmp = new Bitmap(32, 18); _screenG = Graphics.FromImage(_screenBmp); }
                IntPtr hdcDest = _screenG.GetHdc();
                NativeMethods.SetStretchBltMode(hdcDest, 4);
                int cropW = (int)(bounds.Width * 0.42);
                int cropH = (int)(bounds.Height * 0.65);
                int cropX = bounds.X + (bounds.Width - cropW) / 2;
                int cropY = bounds.Y + (bounds.Height - cropH) / 2;
                NativeMethods.StretchBlt(hdcDest, 0, 0, 32, 18, hdcSrc, cropX, cropY, cropW, cropH, 0x00CC0020);
                _screenG.ReleaseHdc(hdcDest);

                var rect = new System.Drawing.Rectangle(0, 0, 32, 18);
                var bmpData = _screenBmp.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                Marshal.Copy(bmpData.Scan0, _screenBuf, 0, _screenBuf.Length);
                _screenBmp.UnlockBits(bmpData);

                double rSum = 0, gSum = 0, bSum = 0, wSum = 0;
                for (int i = 0; i < _screenBuf.Length; i += 4)
                {
                    byte b = _screenBuf[i], g = _screenBuf[i + 1], r = _screenBuf[i + 2];
                    int max = r > g ? (r > b ? r : b) : (g > b ? g : b);
                    int min = r < g ? (r < b ? r : b) : (g < b ? g : b);
                    double sat = (max == 0) ? 0.0 : (double)(max - min) / max;
                    double w = 0.25 + sat * 2.5;
                    rSum += r * w; gSum += g * w; bSum += b * w; wSum += w;
                }
                DrawColor avg = DrawColor.FromArgb((int)Math.Min(255, rSum / wSum), (int)Math.Min(255, gSum / wSum), (int)Math.Min(255, bSum / wSum));
                return HsvToColor(avg.GetHue(), Math.Min(1.0, avg.GetSaturation() * 1.45), Math.Max(0.35, avg.GetBrightness()));
            }
            catch { return _currentColor; }
            finally { if (hdcSrc != IntPtr.Zero) NativeMethods.ReleaseDC(IntPtr.Zero, hdcSrc); }
        }

        private double ReadCpuOrChassisTemp()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher(@"root\WMI", "SELECT CurrentTemperature FROM MSAcpi_ThermalZoneTemperature"))
                {
                    double maxC = -1;
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        double c = (Convert.ToDouble(obj["CurrentTemperature"]) / 10.0) - 273.15;
                        if (c > maxC && c < 120) maxC = c;
                    }
                    if (maxC > 0) return maxC;
                }
            }
            catch { }
            double chassis = Wmi.GetChassisTempCelsius();
            return (chassis > 0 && chassis < 120) ? chassis : 45.0;
        }

        private DrawColor PickRandomVibrantColor(DrawColor? avoid = null)
        {
            double h = _rng.NextDouble() * 360.0;
            if (avoid.HasValue)
            {
                double prevH = avoid.Value.GetHue();
                if (Math.Abs(h - prevH) < 55.0) h = (prevH + 90.0 + _rng.NextDouble() * 180.0) % 360.0;
            }
            return HsvToColor(h, 0.90 + _rng.NextDouble() * 0.10, 1.0);
        }

        private static DrawColor LerpColor(DrawColor a, DrawColor b, double t)
        {
            t = Math.Max(0.0, Math.Min(1.0, t));
            return DrawColor.FromArgb((int)Math.Round(a.R + (b.R - a.R) * t), (int)Math.Round(a.G + (b.G - a.G) * t), (int)Math.Round(a.B + (b.B - a.B) * t));
        }

        private static DrawColor HsvToColor(double h, double s, double v)
        {
            int hi = Convert.ToInt32(Math.Floor(h / 60.0)) % 6;
            double f = h / 60.0 - Math.Floor(h / 60.0);
            v *= 255.0;
            int vI = Convert.ToInt32(v), p = Convert.ToInt32(v * (1 - s)), q = Convert.ToInt32(v * (1 - f * s)), t = Convert.ToInt32(v * (1 - (1 - f) * s));
            switch (hi)
            {
                case 0: return DrawColor.FromArgb(vI, t, p);
                case 1: return DrawColor.FromArgb(q, vI, p);
                case 2: return DrawColor.FromArgb(p, vI, t);
                case 3: return DrawColor.FromArgb(p, q, vI);
                case 4: return DrawColor.FromArgb(t, p, vI);
                default: return DrawColor.FromArgb(vI, p, q);
            }
        }

        public void LoadConfig()
        {
            try
            {
                if (!File.Exists(ConfigPath)) return;
                foreach (string line in File.ReadAllLines(ConfigPath))
                {
                    var p = line.Split('=');
                    if (p.Length != 2) continue;
                    int val;
                    switch (p[0])
                    {
                        case "mode": if (int.TryParse(p[1], out val) && val >= 0 && val < ModeNames.Length) ModeIndex = val; break;
                        case "lockedMode": if (int.TryParse(p[1], out val) && val >= -1 && val < ModeNames.Length) LockedModeIndex = val; break;
                        case "speed": if (int.TryParse(p[1], out val)) Speed = val; break;
                        case "maxBright": if (int.TryParse(p[1], out val)) MaxBright = val; break;
                        case "minBright": if (int.TryParse(p[1], out val)) MinBright = val; break;
                        case "cyc1": CycColor1 = ColorTranslator.FromHtml(p[1]); break;
                        case "cyc2": CycColor2 = ColorTranslator.FromHtml(p[1]); break;
                        case "cyc3": CycColor3 = ColorTranslator.FromHtml(p[1]); break;
                        case "cyc3on": CycUseThree = (p[1] == "1"); break;
                        case "keyCol": KeyColor = ColorTranslator.FromHtml(p[1]); break;
                        case "keyRnd": KeyRandom = (p[1] == "1"); break;
                        case "tCool": TempCoolColor = ColorTranslator.FromHtml(p[1]); break;
                        case "tMid": TempMidColor = ColorTranslator.FromHtml(p[1]); break;
                        case "tHot": TempHotColor = ColorTranslator.FromHtml(p[1]); break;
                        case "tCoolV": if (int.TryParse(p[1], out val)) TempCoolVal = val; break;
                        case "tHotV": if (int.TryParse(p[1], out val)) TempHotVal = val; break;
                        case "batSave": BatterySaver = (p[1] == "1"); break;
                        case "idleOn": IdleSleep = (p[1] == "1"); break;
                        case "idleMin": if (int.TryParse(p[1], out val)) IdleMins = val; break;
                        case "idleDimOn": IdleDim = (p[1] == "1"); break;
                        case "idleDimMin": if (int.TryParse(p[1], out val) && val >= 1 && val <= 15) IdleDimMins = val; break;
                        case "patLock": PatternColorLock = (p[1] == "1"); break;
                        case "patCol": PatternLockColor = ColorTranslator.FromHtml(p[1]); break;
                        case "autoHideOn": AutoHideUi = (p[1] == "1"); break;
                        case "autoHideMin": if (int.TryParse(p[1], out val) && val >= 1 && val <= 15) AutoHideMins = val; break;
                        case "modeOrder":
                            var parts = p[1].Split(',');
                            var list = new System.Collections.Generic.List<int>();
                            foreach (var s in parts) { int idx; if (int.TryParse(s, out idx) && idx >= 0 && idx < ModeNames.Length && !list.Contains(idx)) list.Add(idx); }
                            for (int m = 0; m < ModeNames.Length; m++) if (!list.Contains(m)) list.Add(m);
                            if (list.Count == ModeNames.Length) ModeOrder = list.ToArray();
                            break;
                    }
                }
            }
            catch { }
            if (LockedModeIndex >= 0 && LockedModeIndex < ModeNames.Length)
                ModeIndex = LockedModeIndex;
        }

        public void SaveConfig()
        {
            try
            {
                File.WriteAllLines(ConfigPath, new[]
                {
                    "mode=" + ModeIndex, "lockedMode=" + LockedModeIndex, "speed=" + Speed, "maxBright=" + MaxBright, "minBright=" + MinBright,
                    "cyc1=" + ColorTranslator.ToHtml(CycColor1), "cyc2=" + ColorTranslator.ToHtml(CycColor2),
                    "cyc3=" + ColorTranslator.ToHtml(CycColor3), "cyc3on=" + (CycUseThree ? "1" : "0"),
                    "keyCol=" + ColorTranslator.ToHtml(KeyColor), "keyRnd=" + (KeyRandom ? "1" : "0"),
                    "tCool=" + ColorTranslator.ToHtml(TempCoolColor), "tMid=" + ColorTranslator.ToHtml(TempMidColor),
                    "tHot=" + ColorTranslator.ToHtml(TempHotColor), "tCoolV=" + TempCoolVal, "tHotV=" + TempHotVal,
                    "batSave=" + (BatterySaver ? "1" : "0"), "idleOn=" + (IdleSleep ? "1" : "0"), "idleMin=" + IdleMins,
                    "idleDimOn=" + (IdleDim ? "1" : "0"), "idleDimMin=" + IdleDimMins,
                    "patLock=" + (PatternColorLock ? "1" : "0"), "patCol=" + ColorTranslator.ToHtml(PatternLockColor),
                    "autoHideOn=" + (AutoHideUi ? "1" : "0"), "autoHideMin=" + AutoHideMins,
                    "modeOrder=" + string.Join(",", Array.ConvertAll(ModeOrder, delegate(int x) { return x.ToString(); }))
                });
            }
            catch { }
        }

        public static void TrimMemory()
        {
            try
            {
                GC.Collect(2, GCCollectionMode.Forced, true);
                GC.WaitForPendingFinalizers();
                IntPtr hProc = Process.GetCurrentProcess().Handle;
                NativeMethods.SetProcessWorkingSetSize(hProc, (IntPtr)(-1), (IntPtr)(-1));
                NativeMethods.EmptyWorkingSet(hProc);
            }
            catch { }
        }

        public void Dispose()
        {
            if (_wpfDispatcher != null) { try { _wpfDispatcher.InvokeShutdown(); } catch { } }
            if (_hookId != IntPtr.Zero) NativeMethods.UnhookWindowsHookEx(_hookId);
            Stop();
            if (_trayIcon != null) { _trayIcon.Visible = false; _trayIcon.Dispose(); }
            if (_trayIconOff != null) _trayIconOff.Dispose();
            if (_trayIconOn != null) _trayIconOn.Dispose();
            if (_screenG != null) _screenG.Dispose();
            if (_screenBmp != null) _screenBmp.Dispose();
            Wmi.Dispose();
        }
    }

    // =========================================================
    // Custom Liquid Glass Color Picker Dialog
    // =========================================================
    public class GlassColorPicker : Window
    {
        public DrawColor SelectedColor { get; private set; }
        public bool Confirmed { get; private set; }

        private double _hue = 0, _sat = 1, _val = 1;
        private Border _svPad, _svThumb, _hueBar, _hueThumb, _swatchPreview;
        private System.Windows.Controls.TextBox _hexBox;
        private bool _updatingHex = false, _dragSv = false, _dragHue = false;

        public GlassColorPicker(DrawColor initial, Window owner)
        {
            SelectedColor = initial;
            Owner = owner;
            Width = 310;
            Height = 395;
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Background = System.Windows.Media.Brushes.Transparent;
            ShowInTaskbar = false;

            var chrome = new System.Windows.Shell.WindowChrome { CaptionHeight = 0, GlassFrameThickness = new Thickness(-1), ResizeBorderThickness = new Thickness(0), CornerRadius = new CornerRadius(0), UseAeroCaptionButtons = false };
            System.Windows.Shell.WindowChrome.SetWindowChrome(this, chrome);
            SourceInitialized += OnInit;

            RgbToHsv(initial, out _hue, out _sat, out _val);
            BuildUI();
            UpdateFromHsv();
        }

        private void OnInit(object sender, EventArgs e)
        {
            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            var src = HwndSource.FromHwnd(hwnd);
            if (src != null && src.CompositionTarget != null) src.CompositionTarget.BackgroundColor = Colors.Transparent;
            var margins = new NativeMethods.MARGINS { Left = -1, Right = -1, Top = -1, Bottom = -1 };
            NativeMethods.DwmExtendFrameIntoClientArea(hwnd, ref margins);
            int dark = 1; NativeMethods.DwmSetWindowAttribute(hwnd, NativeMethods.DWMWA_USE_IMMERSIVE_DARK_MODE, ref dark, 4);
            int round = NativeMethods.DWMWCP_ROUND; NativeMethods.DwmSetWindowAttribute(hwnd, NativeMethods.DWMWA_WINDOW_CORNER_PREFERENCE, ref round, 4);
            var accent = new NativeMethods.ACCENT_POLICY { AccentState = 4, AccentFlags = 2, GradientColor = unchecked((int)0x40121622) };
            int size = Marshal.SizeOf(accent); IntPtr ptr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(accent, ptr, false);
            var data = new NativeMethods.WINDOWCOMPOSITIONATTRIBDATA { Attribute = 19, Data = ptr, SizeOfData = size };
            NativeMethods.SetWindowCompositionAttribute(hwnd, ref data);
            Marshal.FreeHGlobal(ptr);
            if (src != null) src.AddHook(WndProc);
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT { public int Left, Top, Right, Bottom; }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            const int WM_NCCALCSIZE = 0x0083;
            const int WM_SIZING = 0x0214;
            if (msg == WM_NCCALCSIZE && wParam != IntPtr.Zero)
            {
                handled = true;
                return IntPtr.Zero;
            }
            if (msg == WM_SIZING)
            {
                var rc = (RECT)Marshal.PtrToStructure(lParam, typeof(RECT));
                double aspect = 390.0 / 680.0;
                int w = rc.Right - rc.Left;
                int h = rc.Bottom - rc.Top;
                int edge = wParam.ToInt32();
                if (edge == 3 || edge == 6) // Top or Bottom drag -> adjust width
                    rc.Right = rc.Left + (int)Math.Round(h * aspect);
                else // Side or Corner drag -> adjust height
                    rc.Bottom = rc.Top + (int)Math.Round(w / aspect);
                Marshal.StructureToPtr(rc, lParam, false);
                handled = true;
            }
            return IntPtr.Zero;
        }

        private void BuildUI()
        {
            bool highContrast = SystemParameters.HighContrast;
            System.Windows.Media.Brush rimBrush = highContrast
                ? (System.Windows.Media.Brush)System.Windows.SystemColors.WindowTextBrush
                : new LinearGradientBrush(
                    new GradientStopCollection
                    {
                        new GradientStop(MediaColor.FromArgb(140, 255, 255, 255), 0.0),
                        new GradientStop(MediaColor.FromArgb(35, 255, 255, 255), 0.5),
                        new GradientStop(MediaColor.FromArgb(75, 255, 255, 255), 1.0)
                    },
                    new System.Windows.Point(0, 0), new System.Windows.Point(1, 1));

            var root = new Border
            {
                Padding = new Thickness(16),
                Background = highContrast ? System.Windows.SystemColors.WindowBrush : new SolidColorBrush(MediaColor.FromArgb(145, 16, 20, 32)),
                BorderBrush = rimBrush,
                BorderThickness = new Thickness(1)
            };
            root.MouseLeftButtonDown += delegate(object s, System.Windows.Input.MouseButtonEventArgs e)
            {
                if (e.OriginalSource == root) { try { DragMove(); } catch { } }
            };

            var stack = new StackPanel();
            stack.Children.Add(new TextBlock { Text = "Pick Color", FontSize = 15, FontWeight = FontWeights.Bold, Foreground = highContrast ? System.Windows.SystemColors.WindowTextBrush : System.Windows.Media.Brushes.White, Margin = new Thickness(0, 0, 0, 10) });

            // 2D Saturation / Value Pad
            var svGrid = new Grid { Height = 165, Margin = new Thickness(0, 0, 0, 10), ClipToBounds = true };
            _svPad = new Border { CornerRadius = new CornerRadius(12), Cursor = System.Windows.Input.Cursors.Cross };
            var svOverlay = new Border { CornerRadius = new CornerRadius(12), IsHitTestVisible = false };
            svOverlay.Background = new LinearGradientBrush(Colors.White, MediaColor.FromArgb(0, 255, 255, 255), 0);
            var svDark = new Border { CornerRadius = new CornerRadius(12), IsHitTestVisible = false };
            svDark.Background = new LinearGradientBrush(MediaColor.FromArgb(0, 0, 0, 0), Colors.Black, 90);
            var svCanvas = new Canvas { IsHitTestVisible = false };
            _svThumb = new Border { Width = 14, Height = 14, CornerRadius = new CornerRadius(7), BorderBrush = System.Windows.Media.Brushes.White, BorderThickness = new Thickness(2), Background = System.Windows.Media.Brushes.Transparent };
            svCanvas.Children.Add(_svThumb);
            svGrid.Children.Add(_svPad); svGrid.Children.Add(svOverlay); svGrid.Children.Add(svDark); svGrid.Children.Add(svCanvas);
            _svPad.MouseLeftButtonDown += delegate(object s, System.Windows.Input.MouseButtonEventArgs e) { _dragSv = true; _svPad.CaptureMouse(); SetSv(e.GetPosition(_svPad)); };
            _svPad.MouseMove += delegate(object s, System.Windows.Input.MouseEventArgs e) { if (_dragSv) SetSv(e.GetPosition(_svPad)); };
            _svPad.MouseLeftButtonUp += delegate { _dragSv = false; _svPad.ReleaseMouseCapture(); };
            stack.Children.Add(svGrid);

            // Rainbow Hue Bar
            var hueGrid = new Grid { Height = 18, Margin = new Thickness(0, 0, 0, 12) };
            var hueGrad = new LinearGradientBrush { StartPoint = new System.Windows.Point(0, 0.5), EndPoint = new System.Windows.Point(1, 0.5) };
            hueGrad.GradientStops.Add(new GradientStop(MediaColor.FromRgb(255, 0, 0), 0.0));
            hueGrad.GradientStops.Add(new GradientStop(MediaColor.FromRgb(255, 255, 0), 0.167));
            hueGrad.GradientStops.Add(new GradientStop(MediaColor.FromRgb(0, 255, 0), 0.333));
            hueGrad.GradientStops.Add(new GradientStop(MediaColor.FromRgb(0, 255, 255), 0.5));
            hueGrad.GradientStops.Add(new GradientStop(MediaColor.FromRgb(0, 0, 255), 0.667));
            hueGrad.GradientStops.Add(new GradientStop(MediaColor.FromRgb(255, 0, 255), 0.833));
            hueGrad.GradientStops.Add(new GradientStop(MediaColor.FromRgb(255, 0, 0), 1.0));
            _hueBar = new Border { CornerRadius = new CornerRadius(9), Background = hueGrad, Cursor = System.Windows.Input.Cursors.Hand };
            var hueCanvas = new Canvas { IsHitTestVisible = false };
            _hueThumb = new Border { Width = 14, Height = 14, CornerRadius = new CornerRadius(7), BorderBrush = System.Windows.Media.Brushes.White, BorderThickness = new Thickness(2), Background = System.Windows.Media.Brushes.Transparent };
            hueCanvas.Children.Add(_hueThumb);
            hueGrid.Children.Add(_hueBar); hueGrid.Children.Add(hueCanvas);
            _hueBar.MouseLeftButtonDown += delegate(object s, System.Windows.Input.MouseButtonEventArgs e) { _dragHue = true; _hueBar.CaptureMouse(); SetHue(e.GetPosition(_hueBar)); };
            _hueBar.MouseMove += delegate(object s, System.Windows.Input.MouseEventArgs e) { if (_dragHue) SetHue(e.GetPosition(_hueBar)); };
            _hueBar.MouseLeftButtonUp += delegate { _dragHue = false; _hueBar.ReleaseMouseCapture(); };
            stack.Children.Add(hueGrid);

            // Preview Swatch + Hex Input
            var hexRow = new Grid { Margin = new Thickness(0, 0, 0, 12) };
            hexRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36) });
            hexRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(10) });
            hexRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _swatchPreview = new Border { Height = 32, CornerRadius = new CornerRadius(10), BorderBrush = new SolidColorBrush(MediaColor.FromArgb(100, 255, 255, 255)), BorderThickness = new Thickness(1) };
            _hexBox = new System.Windows.Controls.TextBox
            {
                Height = 32, Padding = new Thickness(10, 5, 10, 0), FontSize = 13,
                Background = new SolidColorBrush(MediaColor.FromArgb(40, 255, 255, 255)),
                Foreground = System.Windows.Media.Brushes.White,
                BorderBrush = new SolidColorBrush(MediaColor.FromArgb(55, 255, 255, 255)),
                BorderThickness = new Thickness(1), CaretBrush = System.Windows.Media.Brushes.White
            };
            _hexBox.TextChanged += OnHexChanged;
            Grid.SetColumn(_swatchPreview, 0); Grid.SetColumn(_hexBox, 2);
            hexRow.Children.Add(_swatchPreview); hexRow.Children.Add(_hexBox);
            stack.Children.Add(hexRow);

            // Quick Preset Dots
            var presets = new WrapPanel { Margin = new Thickness(0, 0, 0, 14) };
            var presetCols = new[] {
                DrawColor.FromArgb(255, 55, 95), DrawColor.FromArgb(255, 155, 40), DrawColor.FromArgb(60, 235, 145),
                DrawColor.FromArgb(55, 200, 255), DrawColor.FromArgb(90, 130, 255), DrawColor.FromArgb(175, 85, 255),
                DrawColor.FromArgb(255, 90, 210), DrawColor.FromArgb(255, 255, 255)
            };
            foreach (var pc in presetCols)
            {
                var c = pc;
                var dot = new Border
                {
                    Width = 24, Height = 24, CornerRadius = new CornerRadius(12), Margin = new Thickness(0, 0, 8, 0),
                    Background = MainWindow.MakeGlassCapsuleBrush(c.R, c.G, c.B, 105),
                    BorderBrush = new LinearGradientBrush(
                        new GradientStopCollection
                        {
                            new GradientStop(MediaColor.FromArgb(165, 255, 255, 255), 0.0),
                            new GradientStop(MediaColor.FromArgb(45, 255, 255, 255), 0.55),
                            new GradientStop(MediaColor.FromArgb(90, 255, 255, 255), 1.0)
                        },
                        new System.Windows.Point(0, 0), new System.Windows.Point(1, 1)),
                    BorderThickness = new Thickness(1),
                    Cursor = System.Windows.Input.Cursors.Hand
                };
                dot.MouseLeftButtonDown += delegate { RgbToHsv(c, out _hue, out _sat, out _val); UpdateFromHsv(); };
                presets.Children.Add(dot);
            }
            stack.Children.Add(presets);

            // Apply / Cancel Buttons
            var btnRow = new Grid();
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(10) });
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var btnCancel = MakePillBtn("Cancel", MediaColor.FromArgb(45, 255, 255, 255));
            var btnOk = MakePillBtn("Apply", MediaColor.FromArgb(215, 255, 255, 255), MediaColor.FromRgb(16, 20, 32));
            btnCancel.Click += delegate { Confirmed = false; Close(); };
            btnOk.Click += delegate { Confirmed = true; Close(); };
            Grid.SetColumn(btnCancel, 0); Grid.SetColumn(btnOk, 2);
            btnRow.Children.Add(btnCancel); btnRow.Children.Add(btnOk);
            stack.Children.Add(btnRow);

            root.Child = stack;
            Content = root;
            Loaded += delegate { UpdateFromHsv(); };
        }

        private static Button MakePillBtn(string text, MediaColor bg, MediaColor? fg = null)
        {
            var b = new Button
            {
                Content = text, Height = 34, Background = new SolidColorBrush(bg),
                Foreground = new SolidColorBrush(fg ?? Colors.White), FontWeight = FontWeights.SemiBold, Cursor = System.Windows.Input.Cursors.Hand
            };
            var tmpl = new ControlTemplate(typeof(Button));
            var bd = new FrameworkElementFactory(typeof(Border));
            bd.SetValue(Border.CornerRadiusProperty, new CornerRadius(17));
            bd.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Button.BackgroundProperty));
            bd.SetValue(Border.BorderThicknessProperty, new Thickness(1));
            var rim = new LinearGradientBrush(
                new GradientStopCollection
                {
                    new GradientStop(MediaColor.FromArgb(145, 255, 255, 255), 0.0),
                    new GradientStop(MediaColor.FromArgb(35, 255, 255, 255), 0.5),
                    new GradientStop(MediaColor.FromArgb(75, 255, 255, 255), 1.0)
                },
                new System.Windows.Point(0, 0), new System.Windows.Point(1, 1));
            rim.Freeze();
            bd.SetValue(Border.BorderBrushProperty, rim);
            var grid = new FrameworkElementFactory(typeof(Grid));
            var lens = new FrameworkElementFactory(typeof(Border));
            lens.SetValue(Border.CornerRadiusProperty, new CornerRadius(16));
            lens.SetValue(Border.MarginProperty, new Thickness(1));
            lens.SetValue(Border.BorderThicknessProperty, new Thickness(1.2));
            var innerRim = new LinearGradientBrush(
                new GradientStopCollection
                {
                    new GradientStop(MediaColor.FromArgb(145, 255, 255, 255), 0.0),
                    new GradientStop(MediaColor.FromArgb(14, 255, 255, 255), 0.45),
                    new GradientStop(MediaColor.FromArgb(62, 255, 255, 255), 1.0)
                },
                new System.Windows.Point(0, 0), new System.Windows.Point(0, 1));
            innerRim.Freeze();
            var innerSheen = new LinearGradientBrush(
                new GradientStopCollection
                {
                    new GradientStop(MediaColor.FromArgb(56, 255, 255, 255), 0.0),
                    new GradientStop(MediaColor.FromArgb(4, 255, 255, 255), 0.35),
                    new GradientStop(MediaColor.FromArgb(30, 255, 255, 255), 1.0)
                },
                new System.Windows.Point(0, 0), new System.Windows.Point(0, 1));
            innerSheen.Freeze();
            lens.SetValue(Border.BorderBrushProperty, innerRim);
            lens.SetValue(Border.BackgroundProperty, innerSheen);
            lens.SetValue(UIElement.IsHitTestVisibleProperty, false);
            grid.AppendChild(lens);
            var cp = new FrameworkElementFactory(typeof(ContentPresenter));
            cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            cp.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            grid.AppendChild(cp);
            bd.AppendChild(grid);
            tmpl.VisualTree = bd;
            b.Template = tmpl;
            return b;
        }

        private void SetSv(System.Windows.Point pt)
        {
            double w = Math.Max(1, _svPad.ActualWidth), h = Math.Max(1, _svPad.ActualHeight);
            _sat = Math.Max(0, Math.Min(1, pt.X / w));
            _val = Math.Max(0, Math.Min(1, 1.0 - (pt.Y / h)));
            UpdateFromHsv();
        }

        private void SetHue(System.Windows.Point pt)
        {
            double w = Math.Max(1, _hueBar.ActualWidth);
            _hue = Math.Max(0, Math.Min(359.9, (pt.X / w) * 360.0));
            UpdateFromHsv();
        }

        private void OnHexChanged(object sender, TextChangedEventArgs e)
        {
            if (_updatingHex) return;
            try
            {
                string t = _hexBox.Text.Trim();
                if (!t.StartsWith("#")) t = "#" + t;
                if (t.Length == 7)
                {
                    DrawColor c = ColorTranslator.FromHtml(t);
                    RgbToHsv(c, out _hue, out _sat, out _val);
                    UpdateFromHsv(false);
                }
            }
            catch { }
        }

        private void UpdateFromHsv(bool updateText = true)
        {
            DrawColor pureHue = HsvToRgb(_hue, 1.0, 1.0);
            _svPad.Background = new SolidColorBrush(MediaColor.FromRgb(pureHue.R, pureHue.G, pureHue.B));
            SelectedColor = HsvToRgb(_hue, _sat, _val);
            _swatchPreview.Background = MainWindow.MakeGlassCapsuleBrush(SelectedColor.R, SelectedColor.G, SelectedColor.B, 110);

            double svW = _svPad.ActualWidth > 0 ? _svPad.ActualWidth : 276;
            double svH = _svPad.ActualHeight > 0 ? _svPad.ActualHeight : 165;
            Canvas.SetLeft(_svThumb, _sat * svW - 7);
            Canvas.SetTop(_svThumb, (1.0 - _val) * svH - 7);

            double hueW = _hueBar.ActualWidth > 0 ? _hueBar.ActualWidth : 276;
            Canvas.SetLeft(_hueThumb, (_hue / 360.0) * hueW - 7);
            Canvas.SetTop(_hueThumb, 2);

            if (updateText)
            {
                _updatingHex = true;
                _hexBox.Text = string.Format("#{0:X2}{1:X2}{2:X2}", SelectedColor.R, SelectedColor.G, SelectedColor.B);
                _updatingHex = false;
            }
        }

        private static void RgbToHsv(DrawColor c, out double h, out double s, out double v)
        {
            int max = Math.Max(c.R, Math.Max(c.G, c.B)), min = Math.Min(c.R, Math.Min(c.G, c.B));
            h = c.GetHue(); s = (max == 0) ? 0 : 1.0 - (1.0 * min / max); v = max / 255.0;
        }

        private static DrawColor HsvToRgb(double h, double s, double v)
        {
            int hi = Convert.ToInt32(Math.Floor(h / 60.0)) % 6;
            double f = h / 60.0 - Math.Floor(h / 60.0);
            v *= 255.0;
            int vI = Convert.ToInt32(v), p = Convert.ToInt32(v * (1 - s)), q = Convert.ToInt32(v * (1 - f * s)), t = Convert.ToInt32(v * (1 - (1 - f) * s));
            switch (hi)
            {
                case 0: return DrawColor.FromArgb(vI, t, p);
                case 1: return DrawColor.FromArgb(q, vI, p);
                case 2: return DrawColor.FromArgb(p, vI, t);
                case 3: return DrawColor.FromArgb(p, q, vI);
                case 4: return DrawColor.FromArgb(t, p, vI);
                default: return DrawColor.FromArgb(vI, p, q);
            }
        }
    }

    // =========================================================
    // On-Demand WPF Liquid Glass Window
    // =========================================================
    public class MainWindow : Window
    {
        private readonly RgbEngine _engine;
        private Border _rootShell, _ambientOrb;
        private System.Windows.Shapes.Ellipse _orbSmokeBase;
        private Canvas _currentsCanvas;
        private System.Windows.Controls.Image _orbLensImage;
        private ScrollViewer _playlistScroll, _colorsScroll;
        private GradientStop _ambientStop, _liveRimTopStop, _liveRimStop, _liveBgTopStop, _liveBgStop, _liveTransportRimStop, _liveTransportBgStop, _livePanelRimTop, _livePanelRimBot, _liveInnerRimTop, _liveInnerRimBot, _liveSpecTop, _liveSpecBot;
        private DropShadowEffect _orbGlow;
        private SolidColorBrush _orbBrush;
        private SolidColorBrush _tabActiveBg, _tabClearBg, _tabMutedFg, _fgDark;
        private System.Windows.Media.Brush _fgLight, _currentsTextBrush;
        private LinearGradientBrush _playlistLockRimBrush;
        private SolidColorBrush _rowActiveBg, _rowIdleBg, _rowActiveBorder, _rowIdleBorder, _rowSubFg;
        private System.Windows.Threading.DispatcherTimer _autoHideTimer;
        private int _lastUiActivityTick = Environment.TickCount;
        private int _lastUiR = -1, _lastUiG = -1, _lastUiB = -1, _lastUiAlpha = -1;
        private Geometry _orbHoleClip;
        private System.Windows.Point _dragStartPt;
        private int _dragSourcePos = -1, _justDroppedPos = -1;
        private bool _lastBrightInvert = false;
        private DoubleAnimation _animHoverIn, _animHoverOut, _animPressIn, _animPressOut, _animThumbIn, _animThumbOut;
        private Grid _viewPlayer, _viewPlaylist, _viewColors, _viewSystem;
        private StackPanel _playlistItems;
        private TextBlock _playlistLockHint;
        private TextBlock _metaText, _modeTitleText, _modeSubText, _speedVal, _maxBrightVal, _minBrightVal, _tempCoolVal, _tempHotVal, _idleDimMinVal, _idleMinVal, _autoHideMinVal, _statusToast;
        private Slider _speedSlider, _maxBrightSlider, _minBrightSlider, _tempCoolSlider, _tempHotSlider, _idleDimMinSlider, _idleMinSlider, _autoHideMinSlider;
        private Button _btnMin, _btnClose, _btnPrev, _btnPlayPause, _btnNext, _btnTestIcon, _btnPlaylist, _btnClosePlaylist, _btnLockMode, _btnTabPlayer, _btnTabColors, _btnTabSystem;
        private Button _btnCyc1, _btnCyc2, _btnCyc3, _btnKeyCol, _btnPatternLockCol, _btnTempCool, _btnTempMid, _btnTempHot, _btnStartup;
        private CheckBox _chkCyc3, _chkKeyRandom, _chkPatternColorLock, _chkBatterySaver, _chkIdleDim, _chkIdleSleep, _chkAutoHideUi;
        private System.Windows.Shapes.Path _iconPlay, _iconPause, _iconLock;

        private double _dispR = 38, _dispG = 40, _dispB = 46;
        private readonly Stopwatch _renderClock = Stopwatch.StartNew();
        private Action _uiFrameAction;
        private long _lastRenderMs = 0;

        private const string WindowXaml = @"
<Border xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
        xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
        x:Name='RootShell' UseLayoutRounding='True' CornerRadius='0'>
    <Border.Background>
        <RadialGradientBrush Center='0.5,0.34' GradientOrigin='0.5,0.30' RadiusX='0.85' RadiusY='0.65'>
            <GradientStop x:Name='AmbientStop' Color='#55262830' Offset='0.0'/>
            <GradientStop Color='#78141824' Offset='0.58'/>
            <GradientStop Color='#900B0E17' Offset='1.0'/>
        </RadialGradientBrush>
    </Border.Background>
    <Border.Resources>
        <SolidColorBrush x:Key='LiveRimBrush' Color='#556E8BFF'/>
        <LinearGradientBrush x:Key='CurrentsGlowText' StartPoint='0,0' EndPoint='1,0.35'>
            <GradientStop Color='#FFFFB8D2' Offset='0.0'/>
            <GradientStop Color='#FFE6CEFF' Offset='0.48'/>
            <GradientStop Color='#FFFFFFFF' Offset='1.0'/>
        </LinearGradientBrush>
        <LinearGradientBrush x:Key='CurrentsSliderGrad' StartPoint='0,0.5' EndPoint='1,0.5'>
            <GradientStop Color='#FFE85A8F' Offset='0.0'/>
            <GradientStop Color='#FFD8A8FF' Offset='0.52'/>
            <GradientStop Color='#FFFFFFFF' Offset='1.0'/>
        </LinearGradientBrush>
        <LinearGradientBrush x:Key='LiveBtnBorder' StartPoint='0,0' EndPoint='1,1'>
            <GradientStop x:Name='LiveRimTopStop' Color='#60484C58' Offset='0.0'/>
            <GradientStop Color='#26FFFFFF' Offset='0.45'/>
            <GradientStop x:Name='LiveRimStop' Color='#703A3E48' Offset='1.0'/>
        </LinearGradientBrush>
        <LinearGradientBrush x:Key='LiveBtnBg' StartPoint='0,0' EndPoint='1,1'>
            <GradientStop x:Name='LiveBgTopStop' Color='#2430343E' Offset='0.0'/>
            <GradientStop Color='#10FFFFFF' Offset='0.48'/>
            <GradientStop x:Name='LiveBgStop' Color='#45282C36' Offset='1.0'/>
        </LinearGradientBrush>
        <LinearGradientBrush x:Key='LiveInnerRimBrush' StartPoint='0,0' EndPoint='1,1'>
            <GradientStop x:Name='LiveInnerRimTop' Color='#55484C58' Offset='0.0'/>
            <GradientStop Color='#0CFFFFFF' Offset='0.48'/>
            <GradientStop x:Name='LiveInnerRimBot' Color='#55383C46' Offset='1.0'/>
        </LinearGradientBrush>
        <RadialGradientBrush x:Key='LiveInnerShineBrush' Center='0.35,0.28' GradientOrigin='0.35,0.28' RadiusX='0.75' RadiusY='0.75'>
            <GradientStop x:Name='LiveSpecTop' Color='#20404450' Offset='0.0'/>
            <GradientStop Color='#00FFFFFF' Offset='0.70'/>
            <GradientStop x:Name='LiveSpecBot' Color='#24282C36' Offset='1.0'/>
        </RadialGradientBrush>
        <LinearGradientBrush x:Key='LiveTransportBorder' StartPoint='0,0' EndPoint='1,1'>
            <GradientStop x:Name='LiveTransportRimStop' Color='#70484C58' Offset='0.0'/>
            <GradientStop Color='#30FFFFFF' Offset='0.45'/>
            <GradientStop Color='#48FFFFFF' Offset='1.0'/>
        </LinearGradientBrush>
        <LinearGradientBrush x:Key='LiveTransportBg' StartPoint='0,0' EndPoint='1,1'>
            <GradientStop Color='#28FFFFFF' Offset='0.0'/>
            <GradientStop Color='#14FFFFFF' Offset='0.45'/>
            <GradientStop x:Name='LiveTransportBgStop' Color='#55383C46' Offset='1.0'/>
        </LinearGradientBrush>
        <LinearGradientBrush x:Key='LivePanelBorder' StartPoint='0,0' EndPoint='1,1'>
            <GradientStop x:Name='LivePanelRimTop' Color='#66FFFFFF' Offset='0.0'/>
            <GradientStop Color='#16FFFFFF' Offset='0.5'/>
            <GradientStop x:Name='LivePanelRimBot' Color='#55FFFFFF' Offset='1.0'/>
        </LinearGradientBrush>
        <Style x:Key='ScrubberSlider' TargetType='Slider'>
            <Setter Property='IsSnapToTickEnabled' Value='True'/>
            <Setter Property='TickFrequency' Value='1'/>
            <Setter Property='VerticalAlignment' Value='Center'/>
            <Setter Property='Cursor' Value='Hand'/>
            <Setter Property='Template'>
                <Setter.Value>
                    <ControlTemplate TargetType='Slider'>
                        <Grid Height='20' Background='Transparent'>
                            <Border Height='3.5' CornerRadius='1.75' Background='#38FFFFFF' VerticalAlignment='Center'/>
                            <Track x:Name='PART_Track'>
                                <Track.DecreaseRepeatButton>
                                    <RepeatButton Command='Slider.DecreaseLarge' IsTabStop='False'>
                                        <RepeatButton.Template><ControlTemplate TargetType='RepeatButton'><Border Height='3.5' CornerRadius='1.75' Background='{StaticResource CurrentsSliderGrad}' VerticalAlignment='Center'/></ControlTemplate></RepeatButton.Template>
                                    </RepeatButton>
                                </Track.DecreaseRepeatButton>
                                <Track.IncreaseRepeatButton>
                                    <RepeatButton Command='Slider.IncreaseLarge' IsTabStop='False'>
                                        <RepeatButton.Template><ControlTemplate TargetType='RepeatButton'><Border Background='Transparent'/></ControlTemplate></RepeatButton.Template>
                                    </RepeatButton>
                                </Track.IncreaseRepeatButton>
                                <Track.Thumb>
                                    <Thumb x:Name='PART_Thumb' Width='15' Height='15'>
                                        <Thumb.Template>
                                            <ControlTemplate TargetType='Thumb'>
                                                <Border x:Name='ThumbBd' CornerRadius='7.5' BorderThickness='1' Background='#D8FFFFFF'>
                                                    <Border.BorderBrush>
                                                        <LinearGradientBrush StartPoint='0,0' EndPoint='1,1'>
                                                            <GradientStop Color='#EEFFFFFF' Offset='0.0'/>
                                                            <GradientStop Color='#55FFFFFF' Offset='0.55'/>
                                                            <GradientStop Color='#88FFFFFF' Offset='1.0'/>
                                                        </LinearGradientBrush>
                                                    </Border.BorderBrush>
                                                    <Border CornerRadius='6.5' Margin='0.5' BorderThickness='1' IsHitTestVisible='False'>
                                                        <Border.BorderBrush>
                                                            <LinearGradientBrush StartPoint='0,0' EndPoint='0,1'>
                                                                <GradientStop Color='#AAFFFFFF' Offset='0.0'/>
                                                                <GradientStop Color='#10FFFFFF' Offset='0.5'/>
                                                                <GradientStop Color='#44FFFFFF' Offset='1.0'/>
                                                            </LinearGradientBrush>
                                                        </Border.BorderBrush>
                                                        <Border.Background>
                                                            <RadialGradientBrush Center='0.35,0.28' GradientOrigin='0.35,0.28' RadiusX='0.7' RadiusY='0.7'>
                                                                <GradientStop Color='#70FFFFFF' Offset='0.0'/>
                                                                <GradientStop Color='#00FFFFFF' Offset='1.0'/>
                                                            </RadialGradientBrush>
                                                        </Border.Background>
                                                    </Border>
                                                </Border>
                                                <ControlTemplate.Triggers>
                                                    <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='ThumbBd' Property='Background' Value='#FFFFFFFF'/></Trigger>
                                                    <Trigger Property='IsDragging' Value='True'><Setter TargetName='ThumbBd' Property='Background' Value='#FFFFFFFF'/></Trigger>
                                                </ControlTemplate.Triggers>
                                            </ControlTemplate>
                                        </Thumb.Template>
                                    </Thumb>
                                </Track.Thumb>
                            </Track>
                        </Grid>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style x:Key='CircleIconBtn' TargetType='Button'>
            <Setter Property='Width' Value='34'/><Setter Property='Height' Value='34'/>
            <Setter Property='Foreground' Value='{StaticResource CurrentsGlowText}'/><Setter Property='FontSize' Value='13'/><Setter Property='Cursor' Value='Hand'/>
            <Setter Property='Template'>
                <Setter.Value>
                    <ControlTemplate TargetType='Button'>
                        <Border x:Name='Bd' CornerRadius='17' BorderBrush='{StaticResource LiveBtnBorder}' Background='{StaticResource LiveBtnBg}' BorderThickness='1'>
                            <Grid>
                                <Border CornerRadius='16' Margin='1' BorderThickness='1.1' BorderBrush='{StaticResource LiveInnerRimBrush}' Background='{StaticResource LiveInnerShineBrush}' IsHitTestVisible='False'/>
                                <ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center'/>
                            </Grid>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='Bd' Property='BorderBrush' Value='#AAFFFFFF'/><Setter TargetName='Bd' Property='Opacity' Value='0.94'/></Trigger>
                            <Trigger Property='IsPressed' Value='True'><Setter TargetName='Bd' Property='Opacity' Value='0.72'/></Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style x:Key='TransportBtn' TargetType='Button'>
            <Setter Property='Foreground' Value='{StaticResource CurrentsGlowText}'/><Setter Property='Cursor' Value='Hand'/>
            <Setter Property='Template'>
                <Setter.Value>
                    <ControlTemplate TargetType='Button'>
                        <Border x:Name='Bd' Width='{TemplateBinding Height}' Height='{TemplateBinding Height}' CornerRadius='32' BorderBrush='{StaticResource LiveTransportBorder}' Background='{StaticResource LiveTransportBg}' BorderThickness='1'>
                            <Grid>
                                <Border CornerRadius='31' Margin='1' BorderThickness='1.2' BorderBrush='{StaticResource LiveInnerRimBrush}' Background='{StaticResource LiveInnerShineBrush}' IsHitTestVisible='False'/>
                                <ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center'/>
                            </Grid>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='Bd' Property='BorderBrush' Value='#AAFFFFFF'/><Setter TargetName='Bd' Property='Opacity' Value='0.94'/></Trigger>
                            <Trigger Property='IsPressed' Value='True'><Setter TargetName='Bd' Property='Opacity' Value='0.68'/></Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style x:Key='DockTabBtn' TargetType='Button'>
            <Setter Property='Height' Value='32'/><Setter Property='MinWidth' Value='88'/><Setter Property='Margin' Value='5,0'/>
            <Setter Property='Foreground' Value='#AAFFFFFF'/><Setter Property='FontSize' Value='10.5'/><Setter Property='FontWeight' Value='SemiBold'/><Setter Property='Cursor' Value='Hand'/>
            <Setter Property='Template'>
                <Setter.Value>
                    <ControlTemplate TargetType='Button'>
                        <Border x:Name='Bd' CornerRadius='16' Background='{TemplateBinding Background}' BorderBrush='{StaticResource LiveBtnBorder}' BorderThickness='1'>
                            <Grid>
                                <Border CornerRadius='15' Margin='1' BorderThickness='1.1' BorderBrush='{StaticResource LiveInnerRimBrush}' Background='{StaticResource LiveInnerShineBrush}' IsHitTestVisible='False'/>
                                <ContentPresenter Margin='14,0' HorizontalAlignment='Center' VerticalAlignment='Center'/>
                            </Grid>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='Bd' Property='BorderBrush' Value='#AAFFFFFF'/></Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style x:Key='CleanToggle' TargetType='CheckBox'>
            <Setter Property='Foreground' Value='#E6FFFFFF'/><Setter Property='FontSize' Value='12.5'/><Setter Property='Cursor' Value='Hand'/>
            <Setter Property='Template'>
                <Setter.Value>
                    <ControlTemplate TargetType='CheckBox'>
                        <Grid Background='Transparent'>
                            <Grid.ColumnDefinitions><ColumnDefinition Width='*'/><ColumnDefinition Width='Auto'/></Grid.ColumnDefinitions>
                            <ContentPresenter Grid.Column='0' VerticalAlignment='Center' Margin='0,0,10,0'/>
                            <Border x:Name='Track' Grid.Column='1' Width='40' Height='22' CornerRadius='11' Background='{StaticResource LiveInnerShineBrush}' BorderBrush='{StaticResource LiveInnerRimBrush}' BorderThickness='1' VerticalAlignment='Center'>
                                <Border x:Name='Knob' Width='16' Height='16' CornerRadius='8' Background='#66FFFFFF' HorizontalAlignment='Left' Margin='2,0,0,0'>
                                    <Border CornerRadius='7' BorderThickness='1' IsHitTestVisible='False'>
                                        <Border.BorderBrush>
                                            <LinearGradientBrush StartPoint='0,0' EndPoint='1,1'>
                                                <GradientStop Color='#AAFFFFFF' Offset='0.0'/>
                                                <GradientStop Color='#20FFFFFF' Offset='0.5'/>
                                                <GradientStop Color='#50FFFFFF' Offset='1.0'/>
                                            </LinearGradientBrush>
                                        </Border.BorderBrush>
                                    </Border>
                                </Border>
                            </Border>
                        </Grid>
                        <ControlTemplate.Triggers>
                            <Trigger Property='IsChecked' Value='True'>
                                <Setter TargetName='Track' Property='Background' Value='{StaticResource LiveBtnBg}'/>
                                <Setter TargetName='Track' Property='BorderBrush' Value='{StaticResource LiveBtnBorder}'/>
                                <Setter TargetName='Knob' Property='HorizontalAlignment' Value='Right'/>
                                <Setter TargetName='Knob' Property='Margin' Value='0,0,2,0'/>
                                <Setter TargetName='Knob' Property='Background' Value='#CCFFFFFF'/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style x:Key='ColorPill' TargetType='Button'>
            <Setter Property='Height' Value='32'/><Setter Property='MinWidth' Value='92'/><Setter Property='Margin' Value='0,0,8,0'/>
            <Setter Property='FontSize' Value='11.5'/><Setter Property='FontWeight' Value='SemiBold'/><Setter Property='Cursor' Value='Hand'/>
            <Setter Property='Template'>
                <Setter.Value>
                    <ControlTemplate TargetType='Button'>
                        <Border CornerRadius='16' Background='{TemplateBinding Background}' BorderBrush='{StaticResource LiveBtnBorder}' BorderThickness='1'>
                            <Grid>
                                <Border CornerRadius='15' Margin='1' BorderThickness='1.1' BorderBrush='{StaticResource LiveInnerRimBrush}' Background='{StaticResource LiveInnerShineBrush}' IsHitTestVisible='False'/>
                                <ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center' Margin='12,0'/>
                            </Grid>
                        </Border>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        <Style x:Key='SoftPanel' TargetType='Border'>
            <Setter Property='CornerRadius' Value='16'/><Setter Property='Padding' Value='14,12'/><Setter Property='Margin' Value='0,0,0,10'/>
            <Setter Property='BorderThickness' Value='1'/>
            <Setter Property='Background'>
                <Setter.Value><LinearGradientBrush StartPoint='0,0' EndPoint='0,1'><GradientStop Color='#2CFFFFFF' Offset='0'/><GradientStop Color='#14FFFFFF' Offset='0.3'/><GradientStop Color='#1CFFFFFF' Offset='1'/></LinearGradientBrush></Setter.Value>
            </Setter>
            <Setter Property='BorderBrush' Value='{StaticResource LivePanelBorder}'/>
        </Style>
    </Border.Resources>
    <Viewbox Stretch='Uniform'>
    <Grid Width='390' Height='680'>
        <Grid.RowDefinitions><RowDefinition Height='44'/><RowDefinition Height='*'/><RowDefinition Height='66'/></Grid.RowDefinitions>
        <!-- Currents-Style Fluid Streamlines Flowing Around the Orb -->
        <Canvas x:Name='CurrentsCanvas' Grid.RowSpan='3' Panel.ZIndex='0' IsHitTestVisible='False' ClipToBounds='True' Opacity='0.48'/>
        <Grid Grid.Row='0' Panel.ZIndex='2' Margin='18,4,18,0'>
            <Button x:Name='BtnTestIcon' Width='28' Height='28' HorizontalAlignment='Left' VerticalAlignment='Center' ToolTip='Test HP WMI Connection' Style='{StaticResource CircleIconBtn}'>
                <Path Data='M 7 1 L 1 9 L 6 9 L 5 15 L 11 7 L 6 7 Z' Fill='{StaticResource CurrentsGlowText}' Width='10' Height='13' Stretch='Uniform'/>
            </Button>
            <Border Width='36' Height='4' CornerRadius='2' Background='#40FFFFFF' HorizontalAlignment='Center' VerticalAlignment='Top' Margin='0,10,0,0'/>
            <TextBlock x:Name='ModelHeaderText' Text='HP Victus RGB' FontSize='11.5' FontWeight='SemiBold' Foreground='#AAFFFFFF' VerticalAlignment='Bottom' HorizontalAlignment='Center' Margin='0,0,0,4'/>
            <StackPanel Orientation='Horizontal' HorizontalAlignment='Right' VerticalAlignment='Center'>
                <Button x:Name='BtnMin' Content='—' Width='28' Height='28' FontSize='11' Margin='0,0,6,0' Style='{StaticResource CircleIconBtn}'/>
                <Button x:Name='BtnClose' Content='✕' Width='28' Height='28' FontSize='11' Style='{StaticResource CircleIconBtn}'/>
            </StackPanel>
        </Grid>
        <Grid x:Name='ViewPlayer' Panel.ZIndex='2' Grid.Row='1' Margin='26,8,26,0'>
            <Grid.RowDefinitions><RowDefinition Height='*'/><RowDefinition Height='Auto'/><RowDefinition Height='Auto'/><RowDefinition Height='Auto'/><RowDefinition Height='Auto'/><RowDefinition Height='Auto'/></Grid.RowDefinitions>
            <Grid Grid.Row='0' Panel.ZIndex='5' VerticalAlignment='Center' HorizontalAlignment='Center'>
                <!-- Masked Glass Base + Lens-Warped Currents Refraction Lines -->
                <Ellipse x:Name='OrbSmokeBase' Width='148' Height='148' Fill='#22181E2E' IsHitTestVisible='False'/>
                <Image x:Name='OrbLensImage' Width='148' Height='148' IsHitTestVisible='False' Opacity='0.75'>
                    <Image.Clip><EllipseGeometry Center='74,74' RadiusX='73.5' RadiusY='73.5'/></Image.Clip>
                </Image>
                <Border x:Name='AmbientOrb' Width='148' Height='148' CornerRadius='74' Background='#FF262830' BorderThickness='1.1'>
                    <Border.BorderBrush>
                        <LinearGradientBrush StartPoint='0.15,0.1' EndPoint='0.85,0.9'>
                            <GradientStop Color='#AAFFFFFF' Offset='0.0'/>
                            <GradientStop Color='#28FFFFFF' Offset='0.5'/>
                            <GradientStop Color='#48FFFFFF' Offset='1.0'/>
                        </LinearGradientBrush>
                    </Border.BorderBrush>
                    <Border.Effect><DropShadowEffect x:Name='OrbGlow' Color='#262830' BlurRadius='55' ShadowDepth='0' Opacity='0.85'/></Border.Effect>
                </Border>
                <Ellipse Width='148' Height='148' IsHitTestVisible='False'>
                    <Ellipse.Fill>
                        <RadialGradientBrush Center='0.35,0.28' GradientOrigin='0.35,0.28' RadiusX='0.7' RadiusY='0.7'>
                            <GradientStop Color='#55FFFFFF' Offset='0.0'/><GradientStop Color='#00FFFFFF' Offset='0.65'/><GradientStop Color='#44000000' Offset='1.0'/>
                        </RadialGradientBrush>
                    </Ellipse.Fill>
                </Ellipse>
            </Grid>
            <TextBlock x:Name='MetaText' Grid.Row='1' Text='WMI · 1-Zone RGB · Idle' FontSize='11' Foreground='#99FFFFFF' HorizontalAlignment='Center' Margin='0,4,0,18'/>
            <StackPanel Grid.Row='2' Margin='0,0,0,14'>
                <TextBlock x:Name='ModeTitleText' Text='Random Color Pulse' FontSize='19' FontWeight='Bold' Foreground='{StaticResource CurrentsGlowText}' TextTrimming='CharacterEllipsis'/>
                <TextBlock x:Name='ModeSubText' Text='Breathe &amp; switch vibrant colors' FontSize='13' Foreground='#A8FFFFFF' Margin='0,2,0,0' TextTrimming='CharacterEllipsis'/>
            </StackPanel>
            <StackPanel Grid.Row='3' Margin='0,0,0,12'>
                <Slider x:Name='SpeedSlider' Minimum='1' Maximum='20' Value='8' Style='{StaticResource ScrubberSlider}'/>
                <Grid Margin='0,0,0,10'><TextBlock Text='Pulse Speed' FontSize='11' Foreground='#88FFFFFF'/><TextBlock x:Name='SpeedVal' Text='8' FontSize='11' Foreground='#AAFFFFFF' HorizontalAlignment='Right'/></Grid>
                <Grid>
                    <Grid.ColumnDefinitions><ColumnDefinition Width='*'/><ColumnDefinition Width='16'/><ColumnDefinition Width='*'/></Grid.ColumnDefinitions>
                    <StackPanel Grid.Column='0'>
                        <Slider x:Name='MaxBrightSlider' Minimum='20' Maximum='100' Value='100' Style='{StaticResource ScrubberSlider}'/>
                        <Grid><TextBlock Text='Max Bright' FontSize='10.5' Foreground='#88FFFFFF'/><TextBlock x:Name='MaxBrightVal' Text='100%' FontSize='10.5' Foreground='#AAFFFFFF' HorizontalAlignment='Right'/></Grid>
                    </StackPanel>
                    <StackPanel Grid.Column='2'>
                        <Slider x:Name='MinBrightSlider' Minimum='0' Maximum='40' Value='5' Style='{StaticResource ScrubberSlider}'/>
                        <Grid><TextBlock Text='Min Floor' FontSize='10.5' Foreground='#88FFFFFF'/><TextBlock x:Name='MinBrightVal' Text='5%' FontSize='10.5' Foreground='#AAFFFFFF' HorizontalAlignment='Right'/></Grid>
                    </StackPanel>
                </Grid>
            </StackPanel>
            <Grid Grid.Row='4' Margin='12,4,12,8'>
                <Grid.ColumnDefinitions><ColumnDefinition Width='*'/><ColumnDefinition Width='*'/><ColumnDefinition Width='*'/></Grid.ColumnDefinitions>
                <Button x:Name='BtnPrev' Grid.Column='0' Height='50' Style='{StaticResource TransportBtn}'><Path Data='M 14 2 L 4 9 L 14 16 Z M 24 2 L 14 9 L 24 16 Z' Fill='{StaticResource CurrentsGlowText}' Width='26' Height='18' Stretch='Uniform'/></Button>
                <Button x:Name='BtnPlayPause' Grid.Column='1' Height='62' Style='{StaticResource TransportBtn}'>
                    <Grid>
                        <Path x:Name='IconPlay' Data='M 4 2 L 22 13 L 4 24 Z' Fill='{StaticResource CurrentsGlowText}' Width='24' Height='26' Stretch='Uniform' Visibility='Visible'/>
                        <Path x:Name='IconPause' Data='M 3 2 L 9 2 L 9 22 L 3 22 Z M 15 2 L 21 2 L 21 22 L 15 22 Z' Fill='{StaticResource CurrentsGlowText}' Width='22' Height='24' Stretch='Uniform' Visibility='Collapsed'/>
                    </Grid>
                </Button>
                <Button x:Name='BtnNext' Grid.Column='2' Height='50' Style='{StaticResource TransportBtn}'><Path Data='M 2 2 L 12 9 L 2 16 Z M 12 2 L 22 9 L 12 16 Z' Fill='{StaticResource CurrentsGlowText}' Width='26' Height='18' Stretch='Uniform'/></Button>
            </Grid>
            <Grid Grid.Row='5' Margin='0,2,0,2'>
                <Button x:Name='BtnLockMode' Width='30' Height='30' HorizontalAlignment='Left' ToolTip='Lock this preset as default on startup' Style='{StaticResource CircleIconBtn}'>
                    <Path x:Name='IconLock' Data='M 4 7 V 5 A 4 4 0 0 1 12 5 V 7 H 13 A 1 1 0 0 1 14 8 V 14 A 1 1 0 0 1 13 15 H 3 A 1 1 0 0 1 2 14 V 8 A 1 1 0 0 1 3 7 Z M 6 7 H 10 V 5 A 2 2 0 0 0 6 5 Z' Fill='#88FFFFFF' Width='12' Height='14' Stretch='Uniform'/>
                </Button>
                <Button x:Name='BtnPlaylist' Width='30' Height='30' HorizontalAlignment='Right' ToolTip='Preset Playlist' Style='{StaticResource CircleIconBtn}'>
                    <Path Data='M 2 3 H 14 V 5 H 2 Z M 2 7.5 H 14 V 9.5 H 2 Z M 2 12 H 10 V 14 H 2 Z' Fill='{StaticResource CurrentsGlowText}' Width='12' Height='11' Stretch='Uniform'/>
                </Button>
            </Grid>
        </Grid>
        <Grid x:Name='ViewPlaylist' Panel.ZIndex='2' Grid.Row='1' Margin='22,10,22,0' Visibility='Collapsed'>
            <Grid.RowDefinitions><RowDefinition Height='Auto'/><RowDefinition Height='*'/></Grid.RowDefinitions>
            <Grid Grid.Row='0' Margin='2,0,2,10'>
                <StackPanel>
                    <TextBlock Text='Preset Queue' FontSize='19' FontWeight='Bold' Foreground='{StaticResource CurrentsGlowText}'/>
                    <TextBlock x:Name='PlaylistLockHint' Text='Click to play · Drag to reorder · Tap lock to pin' FontSize='11.5' Foreground='#99FFFFFF' Margin='0,2,0,0'/>
                </StackPanel>
                <Button x:Name='BtnClosePlaylist' Content='Done' Width='58' Height='28' FontSize='11.5' HorizontalAlignment='Right' VerticalAlignment='Center' Style='{StaticResource CircleIconBtn}'/>
            </Grid>
            <ScrollViewer x:Name='PlaylistScroll' Grid.Row='1' VerticalScrollBarVisibility='Auto'>
                <ScrollViewer.OpacityMask>
                    <LinearGradientBrush StartPoint='0,0' EndPoint='0,1'>
                        <GradientStop Color='#55000000' Offset='0.0'/>
                        <GradientStop Color='#FF000000' Offset='0.035'/>
                        <GradientStop Color='#FF000000' Offset='0.93'/>
                        <GradientStop Color='#00000000' Offset='1.0'/>
                    </LinearGradientBrush>
                </ScrollViewer.OpacityMask>
                <StackPanel x:Name='PlaylistItems' Margin='0,2,0,10'/>
            </ScrollViewer>
        </Grid>
        <Grid x:Name='ViewColors' Panel.ZIndex='2' Grid.Row='1' Margin='22,12,22,0' Visibility='Collapsed'>
            <ScrollViewer x:Name='ColorsScroll' VerticalScrollBarVisibility='Auto'>
                <ScrollViewer.OpacityMask>
                    <LinearGradientBrush StartPoint='0,0' EndPoint='0,1'>
                        <GradientStop Color='#55000000' Offset='0.0'/>
                        <GradientStop Color='#FF000000' Offset='0.035'/>
                        <GradientStop Color='#FF000000' Offset='0.93'/>
                        <GradientStop Color='#00000000' Offset='1.0'/>
                    </LinearGradientBrush>
                </ScrollViewer.OpacityMask>
                <StackPanel Margin='0,2,0,10'>
                    <TextBlock Text='Color Studio' FontSize='19' FontWeight='Bold' Foreground='{StaticResource CurrentsGlowText}' Margin='2,0,0,12'/>
                    <Border Style='{StaticResource SoftPanel}'>
                        <StackPanel>
                            <TextBlock Text='Custom Palette Cycle (2–3 Colors)' FontSize='12.5' FontWeight='SemiBold' Foreground='#DDFFFFFF' Margin='0,0,0,10'/>
                            <WrapPanel Margin='0,0,0,10'><Button x:Name='BtnCyc1' Content='Color 1' Style='{StaticResource ColorPill}'/><Button x:Name='BtnCyc2' Content='Color 2' Style='{StaticResource ColorPill}'/><Button x:Name='BtnCyc3' Content='Color 3' Style='{StaticResource ColorPill}'/></WrapPanel>
                            <CheckBox x:Name='ChkCyc3' Content='Include 3rd color in cycle' IsChecked='True' Style='{StaticResource CleanToggle}'/>
                        </StackPanel>
                    </Border>
                    <Border Style='{StaticResource SoftPanel}'>
                        <StackPanel>
                            <TextBlock Text='Keypress Flash' FontSize='12.5' FontWeight='SemiBold' Foreground='#DDFFFFFF' Margin='0,0,0,10'/>
                            <Grid><Grid.ColumnDefinitions><ColumnDefinition Width='Auto'/><ColumnDefinition Width='*'/></Grid.ColumnDefinitions><Button x:Name='BtnKeyCol' Content='Flash Color' Style='{StaticResource ColorPill}'/><CheckBox x:Name='ChkKeyRandom' Grid.Column='1' Content='Randomize per key' Style='{StaticResource CleanToggle}'/></Grid>
                        </StackPanel>
                    </Border>
                    <Border Style='{StaticResource SoftPanel}'>
                        <StackPanel>
                            <TextBlock Text='Pattern Color Lock (Pulse / Heartbeat / Music)' FontSize='12.5' FontWeight='SemiBold' Foreground='#DDFFFFFF' Margin='0,0,0,10'/>
                            <Grid><Grid.ColumnDefinitions><ColumnDefinition Width='Auto'/><ColumnDefinition Width='*'/></Grid.ColumnDefinitions><Button x:Name='BtnPatternLockCol' Content='Lock Color' Style='{StaticResource ColorPill}'/><CheckBox x:Name='ChkPatternColorLock' Grid.Column='1' Content='Lock pattern color' Style='{StaticResource CleanToggle}'/></Grid>
                        </StackPanel>
                    </Border>
                    <Border Style='{StaticResource SoftPanel}'>
                        <StackPanel>
                            <TextBlock Text='Thermal Gauge Colors &amp; Range' FontSize='12.5' FontWeight='SemiBold' Foreground='#DDFFFFFF' Margin='0,0,0,10'/>
                            <WrapPanel Margin='0,0,0,10'><Button x:Name='BtnTempCool' Content='Cool' Style='{StaticResource ColorPill}'/><Button x:Name='BtnTempMid' Content='Warm' Style='{StaticResource ColorPill}'/><Button x:Name='BtnTempHot' Content='Hot' Style='{StaticResource ColorPill}'/></WrapPanel>
                            <Slider x:Name='TempCoolSlider' Minimum='30' Maximum='65' Value='45' Style='{StaticResource ScrubberSlider}'/>
                            <Grid Margin='0,0,0,6'><TextBlock Text='Cool Threshold' FontSize='11' Foreground='#88FFFFFF'/><TextBlock x:Name='TempCoolVal' Text='45°C' FontSize='11' Foreground='#CCFFFFFF' HorizontalAlignment='Right'/></Grid>
                            <Slider x:Name='TempHotSlider' Minimum='65' Maximum='95' Value='80' Style='{StaticResource ScrubberSlider}'/>
                            <Grid><TextBlock Text='Hot Threshold' FontSize='11' Foreground='#88FFFFFF'/><TextBlock x:Name='TempHotVal' Text='80°C' FontSize='11' Foreground='#CCFFFFFF' HorizontalAlignment='Right'/></Grid>
                        </StackPanel>
                    </Border>
                </StackPanel>
            </ScrollViewer>
        </Grid>
        <Grid x:Name='ViewSystem' Panel.ZIndex='2' Grid.Row='1' Margin='22,12,22,0' Visibility='Collapsed'>
            <StackPanel>
                <TextBlock Text='Power &amp; Startup' FontSize='19' FontWeight='Bold' Foreground='{StaticResource CurrentsGlowText}' Margin='2,0,0,12'/>
                <Border Style='{StaticResource SoftPanel}'>
                    <StackPanel>
                        <CheckBox x:Name='ChkBatterySaver' Content='Battery Saver (cap at 40% when ≤40% battery)' IsChecked='True' Margin='0,0,0,12' Style='{StaticResource CleanToggle}'/>
                        <CheckBox x:Name='ChkIdleDim' Content='Dim keyboard to 20% when idle' IsChecked='False' Margin='0,0,0,8' Style='{StaticResource CleanToggle}'/>
                        <Slider x:Name='IdleDimMinSlider' Minimum='1' Maximum='15' Value='1' Style='{StaticResource ScrubberSlider}'/>
                        <Grid Margin='0,0,0,12'><TextBlock Text='Idle Dim Delay' FontSize='11' Foreground='#88FFFFFF'/><TextBlock x:Name='IdleDimMinVal' Text='1m' FontSize='11' Foreground='#CCFFFFFF' HorizontalAlignment='Right'/></Grid>
                        <CheckBox x:Name='ChkIdleSleep' Content='Turn off backlight when idle' IsChecked='False' Margin='0,0,0,8' Style='{StaticResource CleanToggle}'/>
                        <Slider x:Name='IdleMinSlider' Minimum='1' Maximum='30' Value='5' Style='{StaticResource ScrubberSlider}'/>
                        <Grid Margin='0,0,0,12'><TextBlock Text='Idle Sleep Delay' FontSize='11' Foreground='#88FFFFFF'/><TextBlock x:Name='IdleMinVal' Text='5m' FontSize='11' Foreground='#CCFFFFFF' HorizontalAlignment='Right'/></Grid>
                        <CheckBox x:Name='ChkAutoHideUi' Content='Auto-close UI to tray when idle' IsChecked='False' Margin='0,0,0,8' Style='{StaticResource CleanToggle}'/>
                        <Slider x:Name='AutoHideMinSlider' Minimum='1' Maximum='15' Value='2' Style='{StaticResource ScrubberSlider}'/>
                        <Grid><TextBlock Text='UI Tray Timeout' FontSize='11' Foreground='#88FFFFFF'/><TextBlock x:Name='AutoHideMinVal' Text='2m' FontSize='11' Foreground='#CCFFFFFF' HorizontalAlignment='Right'/></Grid>
                    </StackPanel>
                </Border>
                <Border Style='{StaticResource SoftPanel}'>
                    <StackPanel>
                        <TextBlock Text='Windows Startup' FontSize='12.5' FontWeight='SemiBold' Foreground='#DDFFFFFF' Margin='0,0,0,10'/>
                        <Button x:Name='BtnStartup' Content='Enable Auto-Start at Boot' Height='36' Background='#30FFFFFF' Foreground='#FFFFFFFF' Style='{StaticResource ColorPill}' MinWidth='200' Margin='0'/>
                    </StackPanel>
                </Border>
                <TextBlock x:Name='StatusToast' Text='Closing this window frees all UI memory (~12 MB in tray).' FontSize='11.5' Foreground='#AAFFFFFF' TextWrapping='Wrap' Margin='4,4,4,0'/>
            </StackPanel>
        </Grid>
        <Grid Grid.Row='2' Panel.ZIndex='2' VerticalAlignment='Center' HorizontalAlignment='Center'>
            <StackPanel Orientation='Horizontal'>
                <Button x:Name='BtnTabPlayer' Content='PLAYER' Background='#734C3E5C' Foreground='{StaticResource CurrentsGlowText}' Style='{StaticResource DockTabBtn}'/>
                <Button x:Name='BtnTabColors' Content='COLORS' Background='#660A0D16' Style='{StaticResource DockTabBtn}'/>
                <Button x:Name='BtnTabSystem' Content='SYSTEM' Background='#660A0D16' Style='{StaticResource DockTabBtn}'/>
            </StackPanel>
        </Grid>
        <Thumb x:Name='ResizeGrip' Grid.Row='2' Panel.ZIndex='10' Width='18' Height='18' HorizontalAlignment='Right' VerticalAlignment='Bottom' Margin='0,0,6,6' Cursor='SizeNWSE'>
            <Thumb.Template>
                <ControlTemplate TargetType='Thumb'>
                    <Grid Background='Transparent'>
                        <Path Data='M 14,4 L 4,14 M 14,9 L 9,14' Stroke='#55FFFFFF' StrokeThickness='1.4' StrokeStartLineCap='Round' StrokeEndLineCap='Round'/>
                    </Grid>
                </ControlTemplate>
            </Thumb.Template>
        </Thumb>
    </Grid>
    </Viewbox>
</Border>";

        public MainWindow(RgbEngine engine)
        {
            _engine = engine;
            Title = "Victus RGB Studio";
            Width = 360;
            Height = 628;
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Background = System.Windows.Media.Brushes.Transparent;
            FontFamily = new System.Windows.Media.FontFamily("Segoe UI Variable Text, Segoe UI");

            try
            {
                using (var ico = RgbEngine.GetAppIcon(_engine.ExePath))
                    Icon = Imaging.CreateBitmapSourceFromHIcon(ico.Handle, Int32Rect.Empty, System.Windows.Media.Imaging.BitmapSizeOptions.FromEmptyOptions());
            }
            catch { }

            MouseLeftButtonDown += delegate(object s, System.Windows.Input.MouseButtonEventArgs e)
            {
                if (e.LeftButton == System.Windows.Input.MouseButtonState.Pressed && !(e.OriginalSource is System.Windows.Controls.Primitives.Thumb))
                { try { DragMove(); } catch { } }
            };

            SourceInitialized += OnSourceInitialized;
            var root = (Border)XamlReader.Parse(WindowXaml);
            _rootShell = root;
            Content = root;
            WireControls(root);
            SyncFromEngine();
            RefreshStartupButton();
            SwitchTab(0);

            _engine.FrameUpdated += OnEngineFrame;
            CompositionTarget.Rendering += OnUiRenderFrame;
            PreviewMouseMove += delegate { _lastUiActivityTick = Environment.TickCount; };
            PreviewMouseDown += delegate { _lastUiActivityTick = Environment.TickCount; };
            PreviewKeyDown += delegate { _lastUiActivityTick = Environment.TickCount; };
            _autoHideTimer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
            _autoHideTimer.Tick += delegate
            {
                if (_engine.AutoHideUi && (uint)(Environment.TickCount - _lastUiActivityTick) >= (uint)(_engine.AutoHideMins * 60000))
                    Close();
            };
            _autoHideTimer.Start();
            Closing += delegate { _autoHideTimer.Stop(); _engine.FrameUpdated -= OnEngineFrame; CompositionTarget.Rendering -= OnUiRenderFrame; };
        }

        private void OnSourceInitialized(object sender, EventArgs e)
        {
            IntPtr hwnd = new WindowInteropHelper(this).Handle;
            var src = HwndSource.FromHwnd(hwnd);
            if (src != null && src.CompositionTarget != null) src.CompositionTarget.BackgroundColor = Colors.Transparent;

            int dark = 1; NativeMethods.DwmSetWindowAttribute(hwnd, NativeMethods.DWMWA_USE_IMMERSIVE_DARK_MODE, ref dark, 4);
            int round = NativeMethods.DWMWCP_ROUND; NativeMethods.DwmSetWindowAttribute(hwnd, NativeMethods.DWMWA_WINDOW_CORNER_PREFERENCE, ref round, 4);
            int noColor = unchecked((int)0xFFFFFFFE); // DWMWA_COLOR_NONE
            NativeMethods.DwmSetWindowAttribute(hwnd, 34, ref noColor, 4); // DWMWA_BORDER_COLOR
            NativeMethods.DwmSetWindowAttribute(hwnd, 35, ref noColor, 4); // DWMWA_CAPTION_COLOR (kills orange top bar)

            // AccentState=3 (DWM BlurBehind) stays 100% frosted translucent even when unfocused & has zero drag lag
            var accent = new NativeMethods.ACCENT_POLICY
            {
                AccentState = 3,
                AccentFlags = 0,
                GradientColor = 0
            };
            int size = Marshal.SizeOf(accent);
            IntPtr ptr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(accent, ptr, false);
            var data = new NativeMethods.WINDOWCOMPOSITIONATTRIBDATA { Attribute = 19, Data = ptr, SizeOfData = size };
            NativeMethods.SetWindowCompositionAttribute(hwnd, ref data);
            Marshal.FreeHGlobal(ptr);
        }

        private static PathGeometry PointsToSmoothBezier(System.Collections.Generic.List<System.Windows.Point> pts)
        {
            var fig = new PathFigure { StartPoint = pts[0], IsClosed = false };
            var bez = new PolyBezierSegment();
            for (int i = 0; i < pts.Count - 1; i++)
            {
                var p0 = pts[Math.Max(0, i - 1)];
                var p1 = pts[i];
                var p2 = pts[i + 1];
                var p3 = pts[Math.Min(pts.Count - 1, i + 2)];
                bez.Points.Add(new System.Windows.Point(p1.X + (p2.X - p0.X) / 6.0, p1.Y + (p2.Y - p0.Y) / 6.0));
                bez.Points.Add(new System.Windows.Point(p2.X - (p3.X - p1.X) / 6.0, p2.Y - (p3.Y - p1.Y) / 6.0));
                bez.Points.Add(p2);
            }
            fig.Segments.Add(bez);
            var g = new PathGeometry();
            g.Figures.Add(fig);
            return g;
        }

        private void BuildCurrentsStreamlines()
        {
            if (_currentsCanvas == null) return;
            _currentsCanvas.Children.Clear();

            // Orb center in window coordinates (390x680): x=195, y=168, radius=78
            double cx = 195.0, cy = 168.0, R = 74.0;
            double cosA = 0.70710678, sinA = 0.70710678;

            for (int lineIdx = -13; lineIdx <= 13; lineIdx++)
            {
                double b = lineIdx * 17.0;
                bool isCrimson = (lineIdx == 0);
                bool isAmber = (lineIdx == 1);

                var bgPts = new System.Collections.Generic.List<System.Windows.Point>(52);

                for (double s = -280; s <= 430; s += 14)
                {
                    // Smooth potential-flow deflection around cylinder (no sharp cusp)
                    double r2 = s * s + b * b + 1800.0;
                    double bFlow = b * (1.0 + (R * R * 1.15) / r2);

                    // Laminar on top-right (b < 0), gentle organic S-wave wake on bottom-left downstream (b >= 0, s > -10)
                    double wake = 0.0;
                    if (b >= -8.0 && s > -30.0)
                    {
                        double sFade = Math.Min(1.0, Math.Max(0.0, (s + 30.0) / 140.0));
                        sFade = sFade * sFade * (3.0 - 2.0 * sFade); // smoothstep
                        double bFade = Math.Exp(-Math.Max(0.0, b - 40.0) / 150.0);
                        wake = sFade * bFade * 11.0 * Math.Sin(s * 0.032 - lineIdx * 0.45);
                    }

                    double u = s;
                    double v = bFlow + wake;
                    double px = cx + u * cosA - v * sinA;
                    double py = cy + u * sinA + v * cosA;
                    bgPts.Add(new System.Windows.Point(px, py));


                }

                System.Windows.Media.Brush stroke;
                double thick = 1.0;
                if (isCrimson)
                {
                    var lg = new LinearGradientBrush { StartPoint = new System.Windows.Point(0, 0), EndPoint = new System.Windows.Point(1, 1) };
                    lg.GradientStops.Add(new GradientStop(MediaColor.FromArgb(165, 255, 55, 110), 0.0));
                    lg.GradientStops.Add(new GradientStop(MediaColor.FromArgb(175, 255, 80, 95), 0.55));
                    lg.GradientStops.Add(new GradientStop(MediaColor.FromArgb(160, 255, 175, 45), 1.0));
                    stroke = lg;
                    thick = 2.5;
                }
                else if (isAmber)
                {
                    stroke = new SolidColorBrush(MediaColor.FromArgb(65, 255, 165, 65));
                    thick = 1.25;
                }
                else
                {
                    byte a = (byte)(Math.Abs(lineIdx) % 2 == 0 ? 44 : 26);
                    stroke = new SolidColorBrush(MediaColor.FromArgb(a, 235, 240, 255));
                }

                var geom = PointsToSmoothBezier(bgPts);
                geom.Freeze();
                stroke.Freeze();
                _currentsCanvas.Children.Add(new System.Windows.Shapes.Path
                {
                    Data = geom,
                    Stroke = stroke,
                    StrokeThickness = thick
                });
            }
        }

        private void RenderOpticalOrbLens()
        {
            if (_currentsCanvas == null || _orbLensImage == null || _ambientOrb == null) return;
            try
            {
                const int S = 148;
                const double R = 74.0;
                // Measure exact laid-out orb position relative to CurrentsCanvas so refracted lines meet the rim seamlessly
                System.Windows.Point orbTopLeft = _ambientOrb.TranslatePoint(new System.Windows.Point(0, 0), _currentsCanvas);

                _currentsCanvas.Clip = null;
                var dv = new DrawingVisual();
                using (var dc = dv.RenderOpen())
                {
                    var vb = new VisualBrush(_currentsCanvas)
                    {
                        ViewboxUnits = BrushMappingMode.Absolute,
                        Viewbox = new Rect(orbTopLeft.X, orbTopLeft.Y, S, S),
                        Stretch = Stretch.Fill
                    };
                    dc.DrawRectangle(vb, null, new Rect(0, 0, S, S));
                }
                var rtb = new System.Windows.Media.Imaging.RenderTargetBitmap(S, S, 96, 96, PixelFormats.Pbgra32);
                rtb.Render(dv);

                int stride = S * 4;
                byte[] src = new byte[S * stride];
                byte[] dst = new byte[S * stride];
                rtb.CopyPixels(src, stride, 0);

                const double nR = 1.49;    // Red channel IOR (bends least)
                const double nG = 1.515;   // Green baseline IOR (~1.51-1.52)
                const double nB = 1.54;    // Blue channel IOR (bends most)
                const double uvDisp = 0.0035; // UV displacement multiplier (0.002-0.005)
                const double f0 = 0.04;    // Schlick F0 at normal incidence (4%)

                for (int y = 0; y < S; y++)
                {
                    double ny = (y - R) / R;
                    for (int x = 0; x < S; x++)
                    {
                        double nx = (x - R) / R;
                        double r2 = nx * nx + ny * ny;
                        if (r2 >= 1.0) continue;

                        double r = Math.Sqrt(r2);
                        double nz = Math.Sqrt(1.0 - r2);
                        // SmoothStep bevel zone: flat center (IOR_eff ~ 1.0), ramps up smoothly toward rim
                        double t = Math.Max(0.0, Math.Min(1.0, (r - 0.18) / 0.82));
                        double smoothBevel = t * t * (3.0 - 2.0 * t);

                        double kR = 1.0, kG = 1.0, kB = 1.0;
                        if (r > 1e-4)
                        {
                            double thetaI = Math.Asin(Math.Min(0.9999, r));
                            double defR = Math.Sin(thetaI - Math.Asin(Math.Min(0.9999, r / nR)));
                            double defG = Math.Sin(thetaI - Math.Asin(Math.Min(0.9999, r / nG)));
                            double defB = Math.Sin(thetaI - Math.Asin(Math.Min(0.9999, r / nB)));

                            double baseFactor = 0.660 * smoothBevel; // eta = 1.0 / 1.515 ~ 0.660
                            double caSplit = uvDisp * smoothBevel * S;
                            kR = Math.Max(0.20, 1.0 - baseFactor * (defR / r) + (caSplit / R));
                            kG = Math.Max(0.20, 1.0 - baseFactor * (defG / r));
                            kB = Math.Max(0.20, 1.0 - baseFactor * (defB / r) - (caSplit / R));
                        }

                        double sxR = R + nx * kR * R, syR = R + ny * kR * R;
                        double sxG = R + nx * kG * R, syG = R + ny * kG * R;
                        double sxB = R + nx * kB * R, syB = R + ny * kB * R;

                        double rVal = SampleSoft(src, S, stride, sxR, syR, 2);
                        double gVal = SampleSoft(src, S, stride, sxG, syG, 1);
                        double bVal = SampleSoft(src, S, stride, sxB, syB, 0);
                        double aVal = SampleSoft(src, S, stride, sxG, syG, 3);

                        // +15% color saturation boost so refracted hues stay vibrant
                        double luma = 0.2126 * rVal + 0.7152 * gVal + 0.0722 * bVal;
                        rVal = Math.Max(0.0, luma + (rVal - luma) * 1.15);
                        gVal = Math.Max(0.0, luma + (gVal - luma) * 1.15);
                        bVal = Math.Max(0.0, luma + (bVal - luma) * 1.15);

                        // Schlick Fresnel rim lighting: F0 + (1 - F0) * (1 - cosTheta)^4
                        double fresnel = (f0 + (1.0 - f0) * Math.Pow(1.0 - nz, 4.0)) * 58.0;

                        // ~2% monochrome micro-noise to prevent banding and mimic scattering
                        int hash = ((x * 73856093) ^ (y * 19349663)) & 0xFF;
                        double grain = ((hash / 255.0) - 0.5) * 6.0;

                        int dstIdx = y * stride + x * 4;
                        dst[dstIdx + 0] = (byte)Math.Max(0, Math.Min(255, bVal + fresnel + grain));
                        dst[dstIdx + 1] = (byte)Math.Max(0, Math.Min(255, gVal + fresnel + grain));
                        dst[dstIdx + 2] = (byte)Math.Max(0, Math.Min(255, rVal + fresnel + grain));
                        dst[dstIdx + 3] = (byte)Math.Max(0, Math.Min(255, aVal + fresnel * 0.72));
                    }
                }

                var wb = new System.Windows.Media.Imaging.WriteableBitmap(S, S, 96, 96, PixelFormats.Pbgra32, null);
                wb.WritePixels(new Int32Rect(0, 0, S, S), dst, stride, 0);
                wb.Freeze();
                _orbLensImage.Source = wb;

                // Exclude the exact laid-out orb interior from CurrentsCanvas so un-refracted lines do not bleed through
                var orbHole = new CombinedGeometry(
                    GeometryCombineMode.Exclude,
                    new RectangleGeometry(new Rect(0, 0, 390, 680)),
                    new EllipseGeometry(new System.Windows.Point(orbTopLeft.X + R, orbTopLeft.Y + R), 73.5, 73.5));
                orbHole.Freeze();
                _orbHoleClip = orbHole;
                if (_viewPlayer != null && _viewPlayer.Visibility == Visibility.Visible)
                    _currentsCanvas.Clip = _orbHoleClip;
            }
            catch { }
        }

        private static double SampleSoft(byte[] buf, int size, int stride, double fx, double fy, int ch)
        {
            double c = SampleChannel(buf, size, stride, fx, fy, ch) * 0.44;
            double n = SampleChannel(buf, size, stride, fx, fy - 1.1, ch) * 0.14;
            double s = SampleChannel(buf, size, stride, fx, fy + 1.1, ch) * 0.14;
            double w = SampleChannel(buf, size, stride, fx - 1.1, fy, ch) * 0.14;
            double e = SampleChannel(buf, size, stride, fx + 1.1, fy, ch) * 0.14;
            return c + n + s + w + e;
        }

        private static double SampleChannel(byte[] buf, int size, int stride, double fx, double fy, int ch)
        {
            int x0 = Math.Max(0, Math.Min(size - 2, (int)fx));
            int y0 = Math.Max(0, Math.Min(size - 2, (int)fy));
            double tx = Math.Max(0.0, Math.Min(1.0, fx - x0));
            double ty = Math.Max(0.0, Math.Min(1.0, fy - y0));

            double c00 = buf[y0 * stride + x0 * 4 + ch];
            double c10 = buf[y0 * stride + (x0 + 1) * 4 + ch];
            double c01 = buf[(y0 + 1) * stride + x0 * 4 + ch];
            double c11 = buf[(y0 + 1) * stride + (x0 + 1) * 4 + ch];

            double top = c00 + (c10 - c00) * tx;
            double bot = c01 + (c11 - c01) * tx;
            return top + (bot - top) * ty;
        }

        private void WireControls(FrameworkElement root)
        {
            _ambientStop = (GradientStop)root.FindName("AmbientStop");
            _liveRimTopStop = (GradientStop)root.FindName("LiveRimTopStop");
            _liveRimStop = (GradientStop)root.FindName("LiveRimStop");
            _liveBgTopStop = (GradientStop)root.FindName("LiveBgTopStop");
            _liveBgStop = (GradientStop)root.FindName("LiveBgStop");
            _liveTransportRimStop = (GradientStop)root.FindName("LiveTransportRimStop");
            _liveTransportBgStop = (GradientStop)root.FindName("LiveTransportBgStop");
            _livePanelRimTop = (GradientStop)root.FindName("LivePanelRimTop");
            _livePanelRimBot = (GradientStop)root.FindName("LivePanelRimBot");
            _liveInnerRimTop = (GradientStop)root.FindName("LiveInnerRimTop");
            _liveInnerRimBot = (GradientStop)root.FindName("LiveInnerRimBot");
            _liveSpecTop = (GradientStop)root.FindName("LiveSpecTop");
            _liveSpecBot = (GradientStop)root.FindName("LiveSpecBot");
            _ambientOrb = (Border)root.FindName("AmbientOrb");
            _orbSmokeBase = (System.Windows.Shapes.Ellipse)root.FindName("OrbSmokeBase");
            _orbLensImage = (System.Windows.Controls.Image)root.FindName("OrbLensImage");
            _currentsCanvas = (Canvas)root.FindName("CurrentsCanvas");
            _playlistScroll = (ScrollViewer)root.FindName("PlaylistScroll");
            _colorsScroll = (ScrollViewer)root.FindName("ColorsScroll");

            if (!SystemParameters.HighContrast)
            {
                BuildCurrentsStreamlines();
                _currentsCanvas.CacheMode = new BitmapCache { EnableClearType = false, RenderAtScale = 1.0 };
                Loaded += delegate { RenderOpticalOrbLens(); };

            }

            _orbGlow = (DropShadowEffect)root.FindName("OrbGlow");
            _viewPlayer = (Grid)root.FindName("ViewPlayer");
            _viewPlaylist = (Grid)root.FindName("ViewPlaylist");
            _playlistItems = (StackPanel)root.FindName("PlaylistItems");
            _playlistLockHint = (TextBlock)root.FindName("PlaylistLockHint");
            _viewColors = (Grid)root.FindName("ViewColors");
            _viewSystem = (Grid)root.FindName("ViewSystem");
            var modelHdr = (TextBlock)root.FindName("ModelHeaderText");
            if (modelHdr != null && !string.IsNullOrEmpty(_engine.ModelName)) modelHdr.Text = _engine.ModelName;
            _metaText = (TextBlock)root.FindName("MetaText");
            _modeTitleText = (TextBlock)root.FindName("ModeTitleText");
            _modeSubText = (TextBlock)root.FindName("ModeSubText");
            _speedSlider = (Slider)root.FindName("SpeedSlider");
            _speedVal = (TextBlock)root.FindName("SpeedVal");
            _maxBrightSlider = (Slider)root.FindName("MaxBrightSlider");
            _maxBrightVal = (TextBlock)root.FindName("MaxBrightVal");
            _minBrightSlider = (Slider)root.FindName("MinBrightSlider");
            _minBrightVal = (TextBlock)root.FindName("MinBrightVal");
            _btnMin = (Button)root.FindName("BtnMin");
            _btnClose = (Button)root.FindName("BtnClose");
            _btnPrev = (Button)root.FindName("BtnPrev");
            _btnPlayPause = (Button)root.FindName("BtnPlayPause");
            _btnNext = (Button)root.FindName("BtnNext");
            _btnTestIcon = (Button)root.FindName("BtnTestIcon");
            _btnPlaylist = (Button)root.FindName("BtnPlaylist");
            _btnClosePlaylist = (Button)root.FindName("BtnClosePlaylist");
            _btnLockMode = (Button)root.FindName("BtnLockMode");
            _iconLock = (System.Windows.Shapes.Path)root.FindName("IconLock");
            _iconPlay = (System.Windows.Shapes.Path)root.FindName("IconPlay");
            _iconPause = (System.Windows.Shapes.Path)root.FindName("IconPause");
            _btnTabPlayer = (Button)root.FindName("BtnTabPlayer");
            _btnTabColors = (Button)root.FindName("BtnTabColors");
            _btnTabSystem = (Button)root.FindName("BtnTabSystem");
            _btnCyc1 = (Button)root.FindName("BtnCyc1");
            _btnCyc2 = (Button)root.FindName("BtnCyc2");
            _btnCyc3 = (Button)root.FindName("BtnCyc3");
            _chkCyc3 = (CheckBox)root.FindName("ChkCyc3");
            _btnKeyCol = (Button)root.FindName("BtnKeyCol");
            _btnPatternLockCol = (Button)root.FindName("BtnPatternLockCol");
            _chkPatternColorLock = (CheckBox)root.FindName("ChkPatternColorLock");
            _chkKeyRandom = (CheckBox)root.FindName("ChkKeyRandom");
            _btnTempCool = (Button)root.FindName("BtnTempCool");
            _btnTempMid = (Button)root.FindName("BtnTempMid");
            _btnTempHot = (Button)root.FindName("BtnTempHot");
            _tempCoolSlider = (Slider)root.FindName("TempCoolSlider");
            _tempCoolVal = (TextBlock)root.FindName("TempCoolVal");
            _tempHotSlider = (Slider)root.FindName("TempHotSlider");
            _tempHotVal = (TextBlock)root.FindName("TempHotVal");
            _chkBatterySaver = (CheckBox)root.FindName("ChkBatterySaver");
            _chkIdleDim = (CheckBox)root.FindName("ChkIdleDim");
            _idleDimMinSlider = (Slider)root.FindName("IdleDimMinSlider");
            _idleDimMinVal = (TextBlock)root.FindName("IdleDimMinVal");
            _chkIdleSleep = (CheckBox)root.FindName("ChkIdleSleep");
            _idleMinSlider = (Slider)root.FindName("IdleMinSlider");
            _idleMinVal = (TextBlock)root.FindName("IdleMinVal");
            _chkAutoHideUi = (CheckBox)root.FindName("ChkAutoHideUi");
            _autoHideMinSlider = (Slider)root.FindName("AutoHideMinSlider");
            _autoHideMinVal = (TextBlock)root.FindName("AutoHideMinVal");
            _btnStartup = (Button)root.FindName("BtnStartup");
            _statusToast = (TextBlock)root.FindName("StatusToast");

            _tabActiveBg = new SolidColorBrush(MediaColor.FromArgb(115, 76, 62, 92));
            _tabActiveBg.Freeze();
            _tabClearBg = new SolidColorBrush(MediaColor.FromArgb(102, 10, 13, 22));
            _tabClearBg.Freeze();
            _tabMutedFg = new SolidColorBrush(MediaColor.FromArgb(170, 255, 255, 255));
            _tabMutedFg.Freeze();
            _currentsTextBrush = root.Resources["CurrentsGlowText"] as System.Windows.Media.Brush;
            _fgLight = _currentsTextBrush ?? System.Windows.Media.Brushes.White;
            _fgDark = new SolidColorBrush(MediaColor.FromRgb(16, 21, 36));
            _fgDark.Freeze();
            _playlistLockRimBrush = new LinearGradientBrush(
                new GradientStopCollection
                {
                    new GradientStop(MediaColor.FromArgb(165, 255, 255, 255), 0.0),
                    new GradientStop(MediaColor.FromArgb(36, 255, 255, 255), 0.5),
                    new GradientStop(MediaColor.FromArgb(95, 255, 255, 255), 1.0)
                },
                new System.Windows.Point(0, 0), new System.Windows.Point(1, 1));
            _playlistLockRimBrush.Freeze();
            _rowActiveBg = new SolidColorBrush(MediaColor.FromArgb(62, 255, 255, 255)); _rowActiveBg.Freeze();
            _rowIdleBg = new SolidColorBrush(MediaColor.FromArgb(24, 255, 255, 255)); _rowIdleBg.Freeze();
            _rowActiveBorder = new SolidColorBrush(MediaColor.FromArgb(95, 255, 255, 255)); _rowActiveBorder.Freeze();
            _rowIdleBorder = new SolidColorBrush(MediaColor.FromArgb(28, 255, 255, 255)); _rowIdleBorder.Freeze();
            _rowSubFg = new SolidColorBrush(MediaColor.FromArgb(165, 255, 255, 255)); _rowSubFg.Freeze();

            if (SystemParameters.HighContrast) ApplyHighContrastFallback();
            else if (SystemParameters.ClientAreaAnimation) InitFluidMotion();

            _btnMin.Click += delegate { Close(); };
            _btnClose.Click += delegate { Close(); };
            _btnTabPlayer.Click += delegate { SwitchTab(0); };
            _btnTabColors.Click += delegate { SwitchTab(1); };
            _btnTabSystem.Click += delegate { SwitchTab(2); };

            _btnPrev.Click += delegate
            {
                int pos = Array.IndexOf(_engine.ModeOrder, _engine.ModeIndex);
                if (pos < 0) pos = 0;
                _engine.ModeIndex = _engine.ModeOrder[(pos + _engine.ModeOrder.Length - 1) % _engine.ModeOrder.Length];
                UpdateModeLabels(); _engine.SaveConfig();
            };
            _btnNext.Click += delegate
            {
                int pos = Array.IndexOf(_engine.ModeOrder, _engine.ModeIndex);
                if (pos < 0) pos = 0;
                _engine.ModeIndex = _engine.ModeOrder[(pos + 1) % _engine.ModeOrder.Length];
                UpdateModeLabels(); _engine.SaveConfig();
            };
            _btnPlayPause.Click += delegate { _engine.Toggle(); Dispatcher.BeginInvoke(new Action(UpdatePlayState), System.Windows.Threading.DispatcherPriority.Background); };
            _btnTestIcon.Click += OnTestClick;
            _btnPlaylist.Click += delegate { BuildPlaylistRows(); _viewPlayer.Visibility = Visibility.Collapsed; _viewPlaylist.Visibility = Visibility.Visible; if (_currentsCanvas != null) _currentsCanvas.Clip = null; };
            _btnClosePlaylist.Click += delegate { _viewPlaylist.Visibility = Visibility.Collapsed; _viewPlayer.Visibility = Visibility.Visible; if (_currentsCanvas != null && _orbHoleClip != null) _currentsCanvas.Clip = _orbHoleClip; };
            _btnLockMode.Click += delegate { ToggleLock(_engine.ModeIndex); };

            _speedSlider.ValueChanged += delegate { _engine.Speed = (int)_speedSlider.Value; _speedVal.Text = _engine.Speed.ToString(); _engine.SaveConfig(); };
            _maxBrightSlider.ValueChanged += delegate { _engine.MaxBright = (int)_maxBrightSlider.Value; _maxBrightVal.Text = _engine.MaxBright + "%"; _engine.SaveConfig(); };
            _minBrightSlider.ValueChanged += delegate { _engine.MinBright = (int)_minBrightSlider.Value; _minBrightVal.Text = _engine.MinBright + "%"; _engine.SaveConfig(); };
            _tempCoolSlider.ValueChanged += delegate { _engine.TempCoolVal = (int)_tempCoolSlider.Value; _tempCoolVal.Text = _engine.TempCoolVal + "°C"; _engine.SaveConfig(); };
            _tempHotSlider.ValueChanged += delegate { _engine.TempHotVal = (int)_tempHotSlider.Value; _tempHotVal.Text = _engine.TempHotVal + "°C"; _engine.SaveConfig(); };
            _idleMinSlider.ValueChanged += delegate { _engine.IdleMins = (int)_idleMinSlider.Value; _idleMinVal.Text = _engine.IdleMins + "m"; _engine.SaveConfig(); };

            _btnCyc1.Click += delegate { PickColor(ref _engine.CycColor1); };
            _btnCyc2.Click += delegate { PickColor(ref _engine.CycColor2); };
            _btnCyc3.Click += delegate { PickColor(ref _engine.CycColor3); };
            _chkCyc3.Checked += delegate { _engine.CycUseThree = true; RefreshColorButtons(); _engine.SaveConfig(); };
            _chkCyc3.Unchecked += delegate { _engine.CycUseThree = false; RefreshColorButtons(); _engine.SaveConfig(); };
            _btnKeyCol.Click += delegate { PickColor(ref _engine.KeyColor); };
            _chkKeyRandom.Checked += delegate { _engine.KeyRandom = true; _engine.SaveConfig(); };
            _chkKeyRandom.Unchecked += delegate { _engine.KeyRandom = false; _engine.SaveConfig(); };
            _btnPatternLockCol.Click += delegate { PickColor(ref _engine.PatternLockColor); };
            _chkPatternColorLock.Checked += delegate { _engine.PatternColorLock = true; _engine.SaveConfig(); };
            _chkPatternColorLock.Unchecked += delegate { _engine.PatternColorLock = false; _engine.SaveConfig(); };
            _btnTempCool.Click += delegate { PickColor(ref _engine.TempCoolColor); };
            _btnTempMid.Click += delegate { PickColor(ref _engine.TempMidColor); };
            _btnTempHot.Click += delegate { PickColor(ref _engine.TempHotColor); };
            _chkBatterySaver.Checked += delegate { _engine.BatterySaver = true; _engine.SaveConfig(); };
            _chkBatterySaver.Unchecked += delegate { _engine.BatterySaver = false; _engine.SaveConfig(); };
            _chkIdleSleep.Checked += delegate { _engine.IdleSleep = true; _engine.SaveConfig(); };
            _chkIdleDim.Checked += delegate { _engine.IdleDim = true; _engine.SaveConfig(); };
            _chkIdleDim.Unchecked += delegate { _engine.IdleDim = false; _engine.IsDimmed = false; _engine.SaveConfig(); };
            _idleDimMinSlider.ValueChanged += delegate { _engine.IdleDimMins = (int)_idleDimMinSlider.Value; _idleDimMinVal.Text = _engine.IdleDimMins + "m"; _engine.SaveConfig(); };
            _chkIdleSleep.Unchecked += delegate { _engine.IdleSleep = false; _engine.SaveConfig(); };
            _chkAutoHideUi.Checked += delegate { _engine.AutoHideUi = true; _lastUiActivityTick = Environment.TickCount; _engine.SaveConfig(); };
            _chkAutoHideUi.Unchecked += delegate { _engine.AutoHideUi = false; _engine.SaveConfig(); };
            _autoHideMinSlider.ValueChanged += delegate { _engine.AutoHideMins = (int)_autoHideMinSlider.Value; _autoHideMinVal.Text = _engine.AutoHideMins + "m"; _engine.SaveConfig(); };
            _btnStartup.Click += OnStartupClick;
            var grip = (System.Windows.Controls.Primitives.Thumb)root.FindName("ResizeGrip");
            if (grip != null)
            {
                grip.DragDelta += delegate(object s2, System.Windows.Controls.Primitives.DragDeltaEventArgs e2)
                {
                    double newW = Math.Max(260, Math.Min(460, Width + e2.HorizontalChange));
                    Width = newW;
                    Height = Math.Round(newW * (680.0 / 390.0));
                };
            }
        }

        private void InitFluidMotion()
        {
            var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
            ease.Freeze();
            var dur = new Duration(TimeSpan.FromMilliseconds(140));
            _animHoverIn = new DoubleAnimation(1.06, dur) { EasingFunction = ease }; _animHoverIn.Freeze();
            _animHoverOut = new DoubleAnimation(1.0, dur) { EasingFunction = ease }; _animHoverOut.Freeze();
            _animPressIn = new DoubleAnimation(0.93, new Duration(TimeSpan.FromMilliseconds(85))) { EasingFunction = ease }; _animPressIn.Freeze();
            _animPressOut = new DoubleAnimation(1.06, dur) { EasingFunction = ease }; _animPressOut.Freeze();
            _animThumbIn = new DoubleAnimation(1.18, dur) { EasingFunction = ease }; _animThumbIn.Freeze();
            _animThumbOut = new DoubleAnimation(1.0, dur) { EasingFunction = ease }; _animThumbOut.Freeze();

            Button[] motionBtns = new[]
            {
                _btnMin, _btnClose, _btnPrev, _btnPlayPause, _btnNext, _btnTestIcon,
                _btnPlaylist, _btnClosePlaylist, _btnLockMode, _btnTabPlayer, _btnTabColors, _btnTabSystem,
                _btnCyc1, _btnCyc2, _btnCyc3, _btnKeyCol, _btnPatternLockCol, _btnTempCool, _btnTempMid, _btnTempHot, _btnStartup
            };
            foreach (var b in motionBtns) AttachButtonMotion(b);

            StartFlowingGradients();
            Loaded += delegate
            {
                Slider[] sliders = new[] { _speedSlider, _maxBrightSlider, _minBrightSlider, _tempCoolSlider, _tempHotSlider, _idleDimMinSlider, _idleMinSlider, _autoHideMinSlider };
                foreach (var s in sliders) AttachThumbMotion(s);
            };
        }

        private void StartFlowingGradients()
        {
            if (_rootShell == null) return;
            var flowEase = new SineEase { EasingMode = EasingMode.EaseInOut };
            flowEase.Freeze();
            var flowDur = new Duration(TimeSpan.FromSeconds(6.5));

            var textBrush = _rootShell.Resources["CurrentsGlowText"] as LinearGradientBrush;
            if (textBrush != null && !textBrush.IsFrozen)
            {
                var pStart = new PointAnimation(new System.Windows.Point(-0.35, 0.0), new System.Windows.Point(0.35, 0.35), flowDur)
                { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = flowEase };
                var pEnd = new PointAnimation(new System.Windows.Point(1.0, 0.35), new System.Windows.Point(1.65, 0.0), flowDur)
                { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = flowEase };
                textBrush.BeginAnimation(LinearGradientBrush.StartPointProperty, pStart);
                textBrush.BeginAnimation(LinearGradientBrush.EndPointProperty, pEnd);
            }

            var sliderBrush = _rootShell.Resources["CurrentsSliderGrad"] as LinearGradientBrush;
            if (sliderBrush != null && !sliderBrush.IsFrozen)
            {
                var sStart = new PointAnimation(new System.Windows.Point(-0.4, 0.5), new System.Windows.Point(0.25, 0.5), flowDur)
                { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = flowEase };
                var sEnd = new PointAnimation(new System.Windows.Point(1.0, 0.5), new System.Windows.Point(1.6, 0.5), flowDur)
                { AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = flowEase };
                sliderBrush.BeginAnimation(LinearGradientBrush.StartPointProperty, sStart);
                sliderBrush.BeginAnimation(LinearGradientBrush.EndPointProperty, sEnd);
            }
        }

        private void AttachButtonMotion(Button b)
        {
            if (b == null) return;
            b.RenderTransformOrigin = new System.Windows.Point(0.5, 0.5);
            var tf = new ScaleTransform(1.0, 1.0);
            b.RenderTransform = tf;
            b.MouseEnter += delegate { tf.BeginAnimation(ScaleTransform.ScaleXProperty, _animHoverIn); tf.BeginAnimation(ScaleTransform.ScaleYProperty, _animHoverIn); };
            b.MouseLeave += delegate { tf.BeginAnimation(ScaleTransform.ScaleXProperty, _animHoverOut); tf.BeginAnimation(ScaleTransform.ScaleYProperty, _animHoverOut); };
            b.PreviewMouseLeftButtonDown += delegate { tf.BeginAnimation(ScaleTransform.ScaleXProperty, _animPressIn); tf.BeginAnimation(ScaleTransform.ScaleYProperty, _animPressIn); };
            b.PreviewMouseLeftButtonUp += delegate
            {
                var anim = b.IsMouseOver ? _animPressOut : _animHoverOut;
                tf.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
                tf.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
            };
        }

        private void AttachThumbMotion(Slider s)
        {
            if (s == null) return;
            s.ApplyTemplate();
            var track = s.Template.FindName("PART_Track", s) as System.Windows.Controls.Primitives.Track;
            if (track == null || track.Thumb == null) return;
            var th = track.Thumb;
            th.RenderTransformOrigin = new System.Windows.Point(0.5, 0.5);
            var tf = new ScaleTransform(1.0, 1.0);
            th.RenderTransform = tf;
            th.MouseEnter += delegate { tf.BeginAnimation(ScaleTransform.ScaleXProperty, _animThumbIn); tf.BeginAnimation(ScaleTransform.ScaleYProperty, _animThumbIn); };
            th.MouseLeave += delegate { if (!th.IsDragging) { tf.BeginAnimation(ScaleTransform.ScaleXProperty, _animThumbOut); tf.BeginAnimation(ScaleTransform.ScaleYProperty, _animThumbOut); } };
            th.DragStarted += delegate { tf.BeginAnimation(ScaleTransform.ScaleXProperty, _animThumbIn); tf.BeginAnimation(ScaleTransform.ScaleYProperty, _animThumbIn); };
            th.DragCompleted += delegate { if (!th.IsMouseOver) { tf.BeginAnimation(ScaleTransform.ScaleXProperty, _animThumbOut); tf.BeginAnimation(ScaleTransform.ScaleYProperty, _animThumbOut); } };
        }

        private void ApplyHighContrastFallback()
        {
            if (_rootShell != null)
            {
                _rootShell.Background = System.Windows.SystemColors.WindowBrush;
                _rootShell.Resources["LiveBtnBorder"] = System.Windows.SystemColors.WindowTextBrush;
                _rootShell.Resources["LiveBtnBg"] = System.Windows.SystemColors.ControlBrush;
                _rootShell.Resources["LiveInnerRimBrush"] = System.Windows.SystemColors.WindowTextBrush;
            }
            if (_currentsCanvas != null) _currentsCanvas.Visibility = Visibility.Collapsed;
            if (_orbLensImage != null) _orbLensImage.Visibility = Visibility.Collapsed;
            if (_ambientOrb != null) { _ambientOrb.Effect = null; _ambientOrb.BorderBrush = System.Windows.SystemColors.WindowTextBrush; }
            if (_orbSmokeBase != null) _orbSmokeBase.Fill = System.Windows.SystemColors.ControlBrush;
            if (_playlistScroll != null) _playlistScroll.OpacityMask = null;
            if (_colorsScroll != null) _colorsScroll.OpacityMask = null;

            Button[] hcBtns = new[] { _btnMin, _btnClose, _btnPrev, _btnPlayPause, _btnNext, _btnTestIcon, _btnPlaylist, _btnClosePlaylist, _btnLockMode };
            foreach (var b in hcBtns)
            {
                if (b != null) { b.Background = System.Windows.SystemColors.ControlBrush; b.Foreground = System.Windows.SystemColors.ControlTextBrush; }
            }
        }

        private void SyncFromEngine()
        {
            _speedSlider.Value = _engine.Speed; _speedVal.Text = _engine.Speed.ToString();
            _maxBrightSlider.Value = _engine.MaxBright; _maxBrightVal.Text = _engine.MaxBright + "%";
            _minBrightSlider.Value = _engine.MinBright; _minBrightVal.Text = _engine.MinBright + "%";
            _chkCyc3.IsChecked = _engine.CycUseThree;
            _chkKeyRandom.IsChecked = _engine.KeyRandom;
            _chkPatternColorLock.IsChecked = _engine.PatternColorLock;
            _tempCoolSlider.Value = _engine.TempCoolVal; _tempCoolVal.Text = _engine.TempCoolVal + "°C";
            _tempHotSlider.Value = _engine.TempHotVal; _tempHotVal.Text = _engine.TempHotVal + "°C";
            _chkBatterySaver.IsChecked = _engine.BatterySaver;
            _chkIdleDim.IsChecked = _engine.IdleDim;
            _idleDimMinSlider.Value = _engine.IdleDimMins; _idleDimMinVal.Text = _engine.IdleDimMins + "m";
            _chkIdleSleep.IsChecked = _engine.IdleSleep;
            _idleMinSlider.Value = _engine.IdleMins; _idleMinVal.Text = _engine.IdleMins + "m";
            _chkAutoHideUi.IsChecked = _engine.AutoHideUi;
            _autoHideMinSlider.Value = _engine.AutoHideMins; _autoHideMinVal.Text = _engine.AutoHideMins + "m";
            _dispR = _engine.TargetR; _dispG = _engine.TargetG; _dispB = _engine.TargetB;
            UpdateModeLabels();
            UpdatePlayState();
            RefreshColorButtons();
            ApplyLiveGlowColors(_engine.TargetR, _engine.TargetG, _engine.TargetB, _engine.IsRunning && !_engine.IsSleeping);
        }

        private void ToggleLock(int idx)
        {
            _engine.LockedModeIndex = (_engine.LockedModeIndex == idx) ? -1 : idx;
            _engine.SaveConfig();
            UpdateModeLabels();
            if (_viewPlaylist.Visibility == Visibility.Visible) BuildPlaylistRows();
        }

        private void UpdateModeLabels()
        {
            _modeTitleText.Text = RgbEngine.ModeNames[_engine.ModeIndex];
            _modeSubText.Text = RgbEngine.ModeSubtitles[_engine.ModeIndex];
            bool isLockedHere = (_engine.LockedModeIndex == _engine.ModeIndex);
            if (_iconLock != null)
                _iconLock.Fill = new SolidColorBrush(isLockedHere ? MediaColor.FromRgb(96, 165, 250) : MediaColor.FromArgb(145, 255, 255, 255));
            if (_playlistLockHint != null)
                _playlistLockHint.Text = (_engine.LockedModeIndex >= 0)
                    ? "Startup locked to: " + RgbEngine.ModeNames[_engine.LockedModeIndex]
                    : "Click to play · Drag to reorder · Tap lock to pin";
        }

        private void BuildPlaylistRows()
        {
            bool hc = SystemParameters.HighContrast;
            _playlistItems.Children.Clear();
            for (int i = 0; i < _engine.ModeOrder.Length; i++)
            {
                int orderPos = i;
                int idx = _engine.ModeOrder[i];
                bool active = (_engine.ModeIndex == idx);
                bool locked = (_engine.LockedModeIndex == idx);

                var row = new Border
                {
                    CornerRadius = new CornerRadius(12),
                    Padding = new Thickness(12, 9, 10, 9),
                    Margin = new Thickness(0, 0, 0, 6),
                    Background = hc
                        ? (active ? System.Windows.SystemColors.HighlightBrush : System.Windows.SystemColors.ControlBrush)
                        : (System.Windows.Media.Brush)(active ? _rowActiveBg : _rowIdleBg),
                    BorderBrush = hc
                        ? System.Windows.SystemColors.WindowTextBrush
                        : (System.Windows.Media.Brush)(active ? _rowActiveBorder : _rowIdleBorder),
                    BorderThickness = new Thickness(1),
                    Cursor = System.Windows.Input.Cursors.Hand
                };

                var g = new Grid();
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var textStack = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                textStack.Children.Add(new TextBlock
                {
                    Text = (active ? "▶  " : "") + RgbEngine.ModeNames[idx],
                    FontSize = 13,
                    FontWeight = active ? FontWeights.Bold : FontWeights.SemiBold,
                    Foreground = hc ? (active ? System.Windows.SystemColors.HighlightTextBrush : System.Windows.SystemColors.ControlTextBrush) : (_currentsTextBrush ?? System.Windows.Media.Brushes.White)
                });
                textStack.Children.Add(new TextBlock
                {
                    Text = RgbEngine.ModeSubtitles[idx],
                    FontSize = 11,
                    Foreground = hc ? (active ? System.Windows.SystemColors.HighlightTextBrush : System.Windows.SystemColors.ControlTextBrush) : (System.Windows.Media.Brush)_rowSubFg,
                    Margin = new Thickness(0, 1, 0, 0)
                });
                Grid.SetColumn(textStack, 0);
                g.Children.Add(textStack);

                var lockBtn = new Button
                {
                    Width = 30, Height = 30,
                    ToolTip = locked ? "Unlock startup preset" : "Lock as startup preset",
                    Background = locked ? (System.Windows.Media.Brush)MakeGlassCapsuleBrush(59, 130, 246, 92) : new SolidColorBrush(MediaColor.FromArgb(30, 255, 255, 255)),
                    Cursor = System.Windows.Input.Cursors.Hand
                };
                var lockTmpl = new ControlTemplate(typeof(Button));
                var lockBd = new FrameworkElementFactory(typeof(Border));
                lockBd.SetValue(Border.CornerRadiusProperty, new CornerRadius(15));
                lockBd.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Button.BackgroundProperty));
                lockBd.SetValue(Border.BorderThicknessProperty, new Thickness(1));
                lockBd.SetValue(Border.BorderBrushProperty, (System.Windows.Media.Brush)_playlistLockRimBrush ?? System.Windows.Media.Brushes.White);
                var lockGrid = new FrameworkElementFactory(typeof(Grid));
                if (!hc)
                {
                    var lockLens = new FrameworkElementFactory(typeof(Border));
                    lockLens.SetValue(Border.CornerRadiusProperty, new CornerRadius(14));
                    lockLens.SetValue(Border.MarginProperty, new Thickness(1));
                    lockLens.SetValue(Border.BorderThicknessProperty, new Thickness(1));
                    lockLens.SetValue(Border.BorderBrushProperty, (System.Windows.Media.Brush)_playlistLockRimBrush ?? System.Windows.Media.Brushes.White);
                    lockLens.SetValue(UIElement.IsHitTestVisibleProperty, false);
                    lockGrid.AppendChild(lockLens);
                }
                var lockIcon = new FrameworkElementFactory(typeof(System.Windows.Shapes.Path));
                lockIcon.SetValue(System.Windows.Shapes.Path.DataProperty, System.Windows.Media.Geometry.Parse("M 4 7 V 5 A 4 4 0 0 1 12 5 V 7 H 13 A 1 1 0 0 1 14 8 V 14 A 1 1 0 0 1 13 15 H 3 A 1 1 0 0 1 2 14 V 8 A 1 1 0 0 1 3 7 Z M 6 7 H 10 V 5 A 2 2 0 0 0 6 5 Z"));
                lockIcon.SetValue(System.Windows.Shapes.Path.FillProperty, new SolidColorBrush(locked ? Colors.White : MediaColor.FromArgb(145, 255, 255, 255)));
                lockIcon.SetValue(FrameworkElement.WidthProperty, 12.0);
                lockIcon.SetValue(FrameworkElement.HeightProperty, 14.0);
                lockIcon.SetValue(System.Windows.Shapes.Path.StretchProperty, Stretch.Uniform);
                lockGrid.AppendChild(lockIcon);
                lockBd.AppendChild(lockGrid);
                lockTmpl.VisualTree = lockBd;
                lockBtn.Template = lockTmpl;

                lockBtn.Click += delegate(object sender2, RoutedEventArgs e2)
                {
                    e2.Handled = true;
                    ToggleLock(idx);
                };
                Grid.SetColumn(lockBtn, 1);
                g.Children.Add(lockBtn);

                var rowScale = new ScaleTransform(1.0, 1.0);
                var rowShift = new TranslateTransform(0.0, 0.0);
                var rowTf = new TransformGroup();
                rowTf.Children.Add(rowScale);
                rowTf.Children.Add(rowShift);
                row.RenderTransformOrigin = new System.Windows.Point(0.5, 0.5);
                row.RenderTransform = rowTf;

                var normalBorder = row.BorderBrush;
                bool animate = SystemParameters.ClientAreaAnimation && !hc;

                if (animate && _justDroppedPos == orderPos)
                {
                    _justDroppedPos = -1;
                    rowScale.ScaleX = 1.045;
                    rowScale.ScaleY = 1.045;
                    var settle = new DoubleAnimation(1.0, new Duration(TimeSpan.FromMilliseconds(180)))
                    {
                        EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
                    };
                    rowScale.BeginAnimation(ScaleTransform.ScaleXProperty, settle);
                    rowScale.BeginAnimation(ScaleTransform.ScaleYProperty, settle);
                }

                row.Child = g;
                row.AllowDrop = true;
                row.PreviewMouseLeftButtonDown += delegate(object s2, System.Windows.Input.MouseButtonEventArgs e2)
                {
                    _dragStartPt = e2.GetPosition(_playlistItems);
                    _dragSourcePos = orderPos;
                };
                row.PreviewMouseMove += delegate(object s2, System.Windows.Input.MouseEventArgs e2)
                {
                    if (e2.LeftButton == System.Windows.Input.MouseButtonState.Pressed && _dragSourcePos == orderPos)
                    {
                        System.Windows.Point cur = e2.GetPosition(_playlistItems);
                        if (Math.Abs(cur.Y - _dragStartPt.Y) > 6.0)
                        {
                            row.Opacity = 0.58;
                            if (animate)
                            {
                                var lift = new DoubleAnimation(1.03, new Duration(TimeSpan.FromMilliseconds(110)));
                                rowScale.BeginAnimation(ScaleTransform.ScaleXProperty, lift);
                                rowScale.BeginAnimation(ScaleTransform.ScaleYProperty, lift);
                            }
                            DragDrop.DoDragDrop(row, orderPos, DragDropEffects.Move);
                            row.Opacity = 1.0;
                            if (animate)
                            {
                                var dropBack = new DoubleAnimation(1.0, new Duration(TimeSpan.FromMilliseconds(140)));
                                rowScale.BeginAnimation(ScaleTransform.ScaleXProperty, dropBack);
                                rowScale.BeginAnimation(ScaleTransform.ScaleYProperty, dropBack);
                            }
                            _dragSourcePos = -1;
                        }
                    }
                };
                row.DragEnter += delegate(object s2, DragEventArgs e2)
                {
                    if (e2.Data.GetDataPresent(typeof(int)))
                    {
                        int srcPos = (int)e2.Data.GetData(typeof(int));
                        if (srcPos != orderPos)
                        {
                            row.BorderBrush = (_rootShell != null && !hc) ? (System.Windows.Media.Brush)_rootShell.Resources["LiveBtnBorder"] : System.Windows.Media.Brushes.White;
                            double shiftY = (srcPos < orderPos) ? -5.0 : 5.0;
                            if (animate)
                            {
                                var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
                                var dur = new Duration(TimeSpan.FromMilliseconds(120));
                                rowShift.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(shiftY, dur) { EasingFunction = ease });
                                rowScale.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(1.018, dur) { EasingFunction = ease });
                                rowScale.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(1.018, dur) { EasingFunction = ease });
                            }
                            else
                            {
                                rowShift.Y = shiftY;
                            }
                        }
                    }
                };
                row.DragLeave += delegate
                {
                    row.BorderBrush = normalBorder;
                    if (animate)
                    {
                        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
                        var dur = new Duration(TimeSpan.FromMilliseconds(120));
                        rowShift.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(0.0, dur) { EasingFunction = ease });
                        rowScale.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(1.0, dur) { EasingFunction = ease });
                        rowScale.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(1.0, dur) { EasingFunction = ease });
                    }
                    else
                    {
                        rowShift.Y = 0.0;
                    }
                };
                row.DragOver += delegate(object s2, DragEventArgs e2)
                {
                    if (e2.Data.GetDataPresent(typeof(int))) { e2.Effects = DragDropEffects.Move; e2.Handled = true; }
                };
                row.Drop += delegate(object s2, DragEventArgs e2)
                {
                    row.BorderBrush = normalBorder;
                    rowShift.BeginAnimation(TranslateTransform.YProperty, null);
                    rowShift.Y = 0.0;
                    if (e2.Data.GetDataPresent(typeof(int)))
                    {
                        int srcPos = (int)e2.Data.GetData(typeof(int));
                        int dstPos = orderPos;
                        if (srcPos >= 0 && srcPos < _engine.ModeOrder.Length && srcPos != dstPos)
                        {
                            int moved = _engine.ModeOrder[srcPos];
                            if (srcPos < dstPos)
                                for (int k = srcPos; k < dstPos; k++) _engine.ModeOrder[k] = _engine.ModeOrder[k + 1];
                            else
                                for (int k = srcPos; k > dstPos; k--) _engine.ModeOrder[k] = _engine.ModeOrder[k - 1];
                            _engine.ModeOrder[dstPos] = moved;
                            _justDroppedPos = dstPos;
                            _engine.SaveConfig();
                            BuildPlaylistRows();
                        }
                    }
                };
                row.MouseLeftButtonUp += delegate
                {
                    _engine.ModeIndex = idx;
                    _engine.SaveConfig();
                    UpdateModeLabels();
                    BuildPlaylistRows();
                };
                _playlistItems.Children.Add(row);
            }
        }

        private void UpdatePlayState()
        {
            _iconPlay.Visibility = _engine.IsRunning ? Visibility.Collapsed : Visibility.Visible;
            _iconPause.Visibility = _engine.IsRunning ? Visibility.Visible : Visibility.Collapsed;
            if (!_engine.IsRunning) { _metaText.Text = "WMI · 1-Zone RGB · Paused"; ApplyLiveGlowColors(_engine.TargetR, _engine.TargetG, _engine.TargetB, false); }
        }

        private void OnEngineFrame()
        {
            if (_uiFrameAction == null)
            {
                _uiFrameAction = delegate
                {
                    UpdatePlayState();
                    if (!string.IsNullOrEmpty(_engine.HardwareWarning)) { _metaText.Text = _engine.HardwareWarning; return; }
                    if (_engine.IsSleeping) { _metaText.Text = "WMI · Idle Sleep"; return; }
                    if (_engine.IsDimmed) { _metaText.Text = string.Format("WMI · Idle Dim (20%) · #{0:X2}{1:X2}{2:X2}", _engine.TargetR, _engine.TargetG, _engine.TargetB); return; }
                    string extra = (_engine.ModeIndex == 8) ? string.Format(" · {0:0}°C", _engine.CachedTemp) : "";
                    _metaText.Text = string.Format("WMI · 1-Zone RGB · #{0:X2}{1:X2}{2:X2}{3}", _engine.TargetR, _engine.TargetG, _engine.TargetB, extra);
                };
            }
            Dispatcher.BeginInvoke(_uiFrameAction);
        }

        private void OnUiRenderFrame(object sender, EventArgs e)
        {
            if (!_engine.IsRunning) return;
            if (SystemParameters.ClientAreaAnimation)
            {
                long now = _renderClock.ElapsedMilliseconds;
                double dt = Math.Min(0.05, Math.Max(0.001, (now - _lastRenderMs) / 1000.0));
                _lastRenderMs = now;

                double alpha = 1.0 - Math.Exp(-dt * 16.0);
                _dispR += (_engine.TargetR - _dispR) * alpha;
                _dispG += (_engine.TargetG - _dispG) * alpha;
                _dispB += (_engine.TargetB - _dispB) * alpha;
            }
            else
            {
                _dispR = _engine.TargetR;
                _dispG = _engine.TargetG;
                _dispB = _engine.TargetB;
            }

            byte r = (byte)Math.Max(0, Math.Min(255, Math.Round(_dispR)));
            byte g = (byte)Math.Max(0, Math.Min(255, Math.Round(_dispG)));
            byte b = (byte)Math.Max(0, Math.Min(255, Math.Round(_dispB)));

            bool highContrast = SystemParameters.HighContrast;
            double intensity = Math.Max(r, Math.Max(g, b)) / 255.0;
            byte orbAlpha = highContrast ? (byte)255 : (byte)Math.Round(35 + 220 * Math.Pow(intensity, 1.45));
            if (r == _lastUiR && g == _lastUiG && b == _lastUiB && orbAlpha == _lastUiAlpha) return;
            _lastUiR = r; _lastUiG = g; _lastUiB = b; _lastUiAlpha = orbAlpha;

            if (_orbLensImage != null && !highContrast && _viewPlayer != null && _viewPlayer.Visibility == Visibility.Visible)
                _orbLensImage.Opacity = Math.Max(0.0, 0.85 * (1.0 - Math.Pow(intensity, 1.2)));
            var orbColor = MediaColor.FromArgb(orbAlpha, r, g, b);
            if (_orbBrush == null) { _orbBrush = new SolidColorBrush(orbColor); _ambientOrb.Background = _orbBrush; }
            else _orbBrush.Color = orbColor;
            if (!highContrast)
            {
                ApplyLiveGlowColors(r, g, b, _engine.IsRunning && !_engine.IsSleeping);

                // Adaptive 0.5 perceived luminance flip on live-tinted controls
                double effLuma = ((0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0) * (orbAlpha / 255.0);
                bool invert = effLuma > 0.50;
                if (invert != _lastBrightInvert && _fgDark != null && _fgLight != null)
                {
                    _lastBrightInvert = invert;
                    var fg = invert ? _fgDark : _fgLight;
                    if (_btnPlayPause != null) _btnPlayPause.Foreground = fg;
                    if (_btnPrev != null) _btnPrev.Foreground = fg;
                    if (_btnNext != null) _btnNext.Foreground = fg;
                }
            }
        }

        private void ApplyLiveGlowColors(byte r, byte g, byte b, bool isActive)
        {
            if (SystemParameters.HighContrast) return;
            // Glow Type 1: Subtle background-colored glow (neutral dark slate, zero blue undertone)
            const byte bgR = 38, bgG = 40, bgB = 46;
            const byte bgRimR = 92, bgRimG = 96, bgB_Rim = 108;

            double activeMix = isActive ? Math.Min(1.0, Math.Max(r, Math.Max(g, b)) / 255.0) : 0.0;
            byte eR = (byte)Math.Round(bgR + (r - bgR) * activeMix);
            byte eG = (byte)Math.Round(bgG + (g - bgG) * activeMix);
            byte eB = (byte)Math.Round(bgB + (b - bgB) * activeMix);

            byte rTint = (byte)Math.Min(255, Math.Round(bgRimR + (Math.Min(255, r * 0.65 + 85) - bgRimR) * activeMix));
            byte gTint = (byte)Math.Min(255, Math.Round(bgRimG + (Math.Min(255, g * 0.65 + 85) - bgRimG) * activeMix));
            byte bTint = (byte)Math.Min(255, Math.Round(bgB_Rim + (Math.Min(255, b * 0.65 + 85) - bgB_Rim) * activeMix));

            byte rimAlpha = (byte)Math.Round(95 + 120 * activeMix);
            byte bgAlpha = (byte)Math.Round(48 + 72 * activeMix);
            byte transRimAlpha = (byte)Math.Round(110 + 135 * activeMix);
            byte transBgAlpha = (byte)Math.Round(54 + 82 * activeMix);

            if (_orbGlow != null && !_orbGlow.IsFrozen) _orbGlow.Color = MediaColor.FromRgb(eR, eG, eB);
            if (_ambientStop != null && !_ambientStop.IsFrozen) _ambientStop.Color = MediaColor.FromArgb((byte)Math.Round(70 + 30 * activeMix), (byte)(eR / 2 + 16), (byte)(eG / 2 + 17), (byte)(eB / 2 + 20));
            if (_liveRimTopStop != null && !_liveRimTopStop.IsFrozen) _liveRimTopStop.Color = MediaColor.FromArgb((byte)Math.Round(105 + 60 * activeMix), rTint, gTint, bTint);
            if (_liveRimStop != null && !_liveRimStop.IsFrozen) _liveRimStop.Color = MediaColor.FromArgb(rimAlpha, eR, eG, eB);
            if (_liveBgTopStop != null && !_liveBgTopStop.IsFrozen) _liveBgTopStop.Color = MediaColor.FromArgb((byte)Math.Round(32 + 16 * activeMix), rTint, gTint, bTint);
            if (_liveBgStop != null && !_liveBgStop.IsFrozen) _liveBgStop.Color = MediaColor.FromArgb(bgAlpha, eR, eG, eB);
            if (_liveTransportRimStop != null && !_liveTransportRimStop.IsFrozen) _liveTransportRimStop.Color = MediaColor.FromArgb(transRimAlpha, rTint, gTint, bTint);
            if (_liveTransportBgStop != null && !_liveTransportBgStop.IsFrozen) _liveTransportBgStop.Color = MediaColor.FromArgb(transBgAlpha, eR, eG, eB);
            if (_livePanelRimTop != null && !_livePanelRimTop.IsFrozen) _livePanelRimTop.Color = MediaColor.FromArgb((byte)Math.Round(80 + 45 * activeMix), rTint, gTint, bTint);
            if (_livePanelRimBot != null && !_livePanelRimBot.IsFrozen) _livePanelRimBot.Color = MediaColor.FromArgb((byte)Math.Round(75 + 60 * activeMix), eR, eG, eB);
            if (_liveInnerRimTop != null && !_liveInnerRimTop.IsFrozen) _liveInnerRimTop.Color = MediaColor.FromArgb((byte)Math.Round(85 + 50 * activeMix), rTint, gTint, bTint);
            if (_liveInnerRimBot != null && !_liveInnerRimBot.IsFrozen) _liveInnerRimBot.Color = MediaColor.FromArgb((byte)Math.Round(80 + 70 * activeMix), eR, eG, eB);
            if (_liveSpecTop != null && !_liveSpecTop.IsFrozen) _liveSpecTop.Color = MediaColor.FromArgb((byte)Math.Round(28 + 18 * activeMix), rTint, gTint, bTint);
            if (_liveSpecBot != null && !_liveSpecBot.IsFrozen) _liveSpecBot.Color = MediaColor.FromArgb((byte)Math.Round(30 + 24 * activeMix), eR, eG, eB);
        }

        private void SwitchTab(int tab)
        {
            _viewPlayer.Visibility = (tab == 0) ? Visibility.Visible : Visibility.Collapsed;
            _viewPlaylist.Visibility = Visibility.Collapsed;
            _viewColors.Visibility = (tab == 1) ? Visibility.Visible : Visibility.Collapsed;
            _viewSystem.Visibility = (tab == 2) ? Visibility.Visible : Visibility.Collapsed;
            if (_currentsCanvas != null) _currentsCanvas.Clip = (tab == 0) ? _orbHoleClip : null;
            bool hc = SystemParameters.HighContrast;
            var activeBg = hc ? System.Windows.SystemColors.HighlightBrush : (System.Windows.Media.Brush)_tabActiveBg;
            var clearBg = hc ? System.Windows.SystemColors.ControlBrush : (System.Windows.Media.Brush)_tabClearBg;
            var activeFg = hc ? System.Windows.SystemColors.HighlightTextBrush : (_currentsTextBrush ?? System.Windows.Media.Brushes.White);
            var mutedFg = hc ? System.Windows.SystemColors.ControlTextBrush : (System.Windows.Media.Brush)_tabMutedFg;
            _btnTabPlayer.Background = (tab == 0) ? activeBg : clearBg; _btnTabPlayer.Foreground = (tab == 0) ? activeFg : mutedFg;
            _btnTabColors.Background = (tab == 1) ? activeBg : clearBg; _btnTabColors.Foreground = (tab == 1) ? activeFg : mutedFg;
            _btnTabSystem.Background = (tab == 2) ? activeBg : clearBg; _btnTabSystem.Foreground = (tab == 2) ? activeFg : mutedFg;
        }

        private void PickColor(ref DrawColor target)
        {
            var dlg = new GlassColorPicker(target, this);
            dlg.ShowDialog();
            if (dlg.Confirmed) { target = dlg.SelectedColor; RefreshColorButtons(); _engine.SaveConfig(); }
        }

        private void RefreshColorButtons()
        {
            SetSwatch(_btnCyc1, _engine.CycColor1); SetSwatch(_btnCyc2, _engine.CycColor2); SetSwatch(_btnCyc3, _engine.CycColor3);
            _btnCyc3.IsEnabled = _engine.CycUseThree; _btnCyc3.Opacity = _engine.CycUseThree ? 1.0 : 0.35;
            SetSwatch(_btnKeyCol, _engine.KeyColor);
            SetSwatch(_btnPatternLockCol, _engine.PatternLockColor);
            SetSwatch(_btnTempCool, _engine.TempCoolColor); SetSwatch(_btnTempMid, _engine.TempMidColor); SetSwatch(_btnTempHot, _engine.TempHotColor);
        }

        internal static LinearGradientBrush MakeGlassCapsuleBrush(byte r, byte g, byte b, byte alphaBase)
        {
            byte rHi = (byte)Math.Min(255, r + 30);
            byte gHi = (byte)Math.Min(255, g + 30);
            byte bHi = (byte)Math.Min(255, b + 30);
            byte rLo = (byte)(r * 0.78);
            byte gLo = (byte)(g * 0.78);
            byte bLo = (byte)(b * 0.78);
            var lg = new LinearGradientBrush { StartPoint = new System.Windows.Point(0, 0), EndPoint = new System.Windows.Point(1, 1) };
            lg.GradientStops.Add(new GradientStop(MediaColor.FromArgb((byte)Math.Min(255, alphaBase + 25), rHi, gHi, bHi), 0.0));
            lg.GradientStops.Add(new GradientStop(MediaColor.FromArgb(alphaBase, r, g, b), 0.52));
            lg.GradientStops.Add(new GradientStop(MediaColor.FromArgb((byte)Math.Min(255, alphaBase + 35), rLo, gLo, bLo), 1.0));
            lg.Freeze();
            return lg;
        }

        private static void SetSwatch(Button b, DrawColor c)
        {
            b.Background = SystemParameters.HighContrast
                ? (System.Windows.Media.Brush)new SolidColorBrush(MediaColor.FromRgb(c.R, c.G, c.B))
                : MakeGlassCapsuleBrush(c.R, c.G, c.B, 82);
            double blendedLuma = ((0.2126 * c.R + 0.7152 * c.G + 0.0722 * c.B) / 255.0) * 0.34 + 0.08;
            b.Foreground = blendedLuma > 0.50 ? System.Windows.Media.Brushes.Black : System.Windows.Media.Brushes.White;
        }

        private void OnTestClick(object sender, RoutedEventArgs e)
        {
            if (!_engine.Wmi.Connect()) { _metaText.Text = "WMI Error · " + _engine.Wmi.LastError; return; }
            uint rcT, rcTab;
            int ktype = _engine.Wmi.GetKeyboardType(out rcT);
            byte[] tab = _engine.Wmi.ReadColorTable(out rcTab);
            if (tab != null && tab.Length >= 28 && rcTab == 0)
            {
                _engine.OriginalTable = tab;
                _metaText.Text = string.Format("WMI OK · Type {0} · Current #{1:X2}{2:X2}{3:X2}", ktype, tab[25], tab[26], tab[27]);
            }
            else if (ktype == 3) _metaText.Text = "Per-key USB RGB (not WMI)"; else _metaText.Text = "WMI Type " + ktype + " · rc=" + rcTab;
        }

        private static bool IsStartupTaskInstalled()
        {
            try
            {
                var psi = new ProcessStartInfo("schtasks.exe", "/Query /TN \"" + RgbEngine.TaskName + "\"")
                { CreateNoWindow = true, UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true };
                using (var p = Process.Start(psi)) { p.WaitForExit(3000); return p.ExitCode == 0; }
            }
            catch { return false; }
        }

        private void RefreshStartupButton()
        {
            if (IsStartupTaskInstalled())
            {
                _btnStartup.Content = "Auto-Start Enabled (Click to Remove)";
                _btnStartup.Background = SystemParameters.HighContrast ? (System.Windows.Media.Brush)new SolidColorBrush(MediaColor.FromRgb(34, 135, 85)) : MakeGlassCapsuleBrush(34, 155, 95, 88);
            }
            else
            {
                _btnStartup.Content = "Enable Auto-Start at Boot (Silent Tray)";
                _btnStartup.Background = new SolidColorBrush(MediaColor.FromArgb(48, 255, 255, 255));
            }
        }

        private void OnStartupClick(object sender, RoutedEventArgs e)
        {
            if (IsStartupTaskInstalled())
            {
                RunPowerShell("Unregister-ScheduledTask -TaskName '" + RgbEngine.TaskName + "' -Confirm:$false");
                _statusToast.Text = "Startup task removed.";
            }
            else
            {
                string escapedExe = _engine.ExePath.Replace("'", "''");
                string psCmd = string.Format(
                    "$action = New-ScheduledTaskAction -Execute '{0}' -Argument '-autostart -minimized'; " +
                    "$trigger = New-ScheduledTaskTrigger -AtLogOn; $trigger.Delay = 'PT15S'; " +
                    "$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Days 0); " +
                    "$user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name; " +
                    "$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest; " +
                    "Register-ScheduledTask -TaskName '{1}' -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null",
                    escapedExe, RgbEngine.TaskName);
                int code = RunPowerShell(psCmd);
                _statusToast.Text = code == 0 ? "Auto-start enabled for VictusRgbStudio.exe!" : "Startup install exit " + code;
            }
            RefreshStartupButton();
        }

        private static int RunPowerShell(string command)
        {
            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(command));
            var psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -EncodedCommand " + encoded) { CreateNoWindow = true, UseShellExecute = false };
            using (var p = Process.Start(psi)) { p.WaitForExit(8000); return p.ExitCode; }
        }
    }

    public static class Program
    {
        private static readonly object _crashLock = new object();

        public static void LogCrash(string source, Exception ex)
        {
            try
            {
                string logPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "victus_crash.log");
                var sb = new StringBuilder();
                sb.AppendLine("============================================================");
                sb.AppendLine(string.Format("[{0:yyyy-MM-dd HH:mm:ss.fff}] Source: {1}", DateTime.Now, source));
                sb.AppendLine(ex != null ? ex.ToString() : "Unknown non-CLS exception");
                sb.AppendLine();
                lock (_crashLock)
                {
                    File.AppendAllText(logPath, sb.ToString(), Encoding.UTF8);
                }
            }
            catch { }
        }

        [STAThread]
        public static void Main(string[] args)
        {
            AppDomain.CurrentDomain.UnhandledException += delegate(object s, UnhandledExceptionEventArgs e)
            {
                LogCrash("AppDomain.UnhandledException (Terminating=" + e.IsTerminating + ")", e.ExceptionObject as Exception);
            };
            WinForms.Application.SetUnhandledExceptionMode(WinForms.UnhandledExceptionMode.CatchException);
            WinForms.Application.ThreadException += delegate(object s, ThreadExceptionEventArgs e)
            {
                LogCrash("WinForms.ThreadException", e.Exception);
            };

            try
            {
                bool autoStart = false, minimized = false;
                foreach (string a in args)
                {
                    if (a.Equals("-autostart", StringComparison.OrdinalIgnoreCase)) autoStart = true;
                    if (a.Equals("-minimized", StringComparison.OrdinalIgnoreCase)) minimized = true;
                }

                var principal = new WindowsPrincipal(WindowsIdentity.GetCurrent());
                if (!principal.IsInRole(WindowsBuiltInRole.Administrator))
                {
                    var psi = new ProcessStartInfo(Assembly.GetExecutingAssembly().Location) { Verb = "runas", Arguments = string.Join(" ", args) };
                    try { Process.Start(psi); } catch { }
                    return;
                }

                using (var engine = new RgbEngine(autoStart, minimized))
                {
                    WinForms.Application.Run();
                }
            }
            catch (Exception ex)
            {
                LogCrash("Program.Main", ex);
                throw;
            }
        }
    }
}