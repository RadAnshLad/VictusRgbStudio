@echo off
setlocal
cd /d "%~dp0"

set "OUT_EXE=VictusRgbStudio.exe"
set "SRC_CS=victusrgbstudio.cs"
set "ICON_FILE=VictusRgbStudio.ico"

:BUILD_LOOP
cls
if not exist "%SRC_CS%" (
    echo ERROR: %SRC_CS% not found in "%~dp0".
    goto :PROMPT_ACTION
)

taskkill /F /IM "%OUT_EXE%" >nul 2>&1
timeout /t 1 /nobreak >nul

if exist "%OUT_EXE%" (
    echo Cleaning up previous %OUT_EXE%...
    del /f /q "%OUT_EXE%"
    if exist "%OUT_EXE%" (
        echo ERROR: Could not delete %OUT_EXE%. Close it from the system tray and retry.
        goto :PROMPT_ACTION
    )
)
if exist "VictusRgbStudio.pdb" del /f /q "VictusRgbStudio.pdb"

set "CSC=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
    echo ERROR: .NET Framework 4.x csc.exe not found.
    goto :PROMPT_ACTION
)

set "WPF_DIR=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\WPF"
if not exist "%WPF_DIR%" set "WPF_DIR=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\WPF"

set "ICON_OPT="
if exist "%ICON_FILE%" (
    echo Embedding icon: %ICON_FILE%
    set "ICON_OPT=/win32icon:%ICON_FILE%"
) else (
    echo WARNING: %ICON_FILE% not found in "%~dp0". Building without custom icon.
)

"%CSC%" /nologo /target:winexe /optimize+ /out:"%OUT_EXE%" %ICON_OPT% ^
    /reference:System.dll ^
    /reference:System.Core.dll ^
    /reference:System.Drawing.dll ^
    /reference:System.Management.dll ^
    /reference:System.Windows.Forms.dll ^
    /reference:System.Xml.dll ^
    /reference:System.Xaml.dll ^
    /reference:"%WPF_DIR%\PresentationCore.dll" ^
    /reference:"%WPF_DIR%\PresentationFramework.dll" ^
    /reference:"%WPF_DIR%\WindowsBase.dll" ^
    "%SRC_CS%"

if errorlevel 1 (
    echo.
    echo Build failed.
    goto :PROMPT_ACTION
)

if exist "%SystemRoot%\System32\ie4uinit.exe" (
    "%SystemRoot%\System32\ie4uinit.exe" -ClearIconCache >nul 2>&1
    "%SystemRoot%\System32\ie4uinit.exe" -show >nul 2>&1
)

echo.
echo Build succeeded: %OUT_EXE%

:PROMPT_ACTION
echo.
set "ACT="
set /p "ACT=[R] Rebuild, [L] Launch, [I] Reset Win11 Icon Cache, [Q] Quit: "
if /I "%ACT%"=="Q" exit /b 0
if /I "%ACT%"=="L" (
    if exist "%OUT_EXE%" start "" "%OUT_EXE%"
    goto :PROMPT_ACTION
)
if /I "%ACT%"=="I" (
    echo Resetting Windows 11 icon cache...
    taskkill /F /IM explorer.exe >nul 2>&1
    timeout /t 1 /nobreak >nul
    del /f /q "%LocalAppData%\IconCache.db" >nul 2>&1
    del /f /q "%LocalAppData%\Microsoft\Windows\Explorer\iconcache_*.db" >nul 2>&1
    start explorer.exe
    echo Icon cache cleared!
    goto :PROMPT_ACTION
)
if /I "%ACT%"=="R" goto :BUILD_LOOP
goto :PROMPT_ACTION
